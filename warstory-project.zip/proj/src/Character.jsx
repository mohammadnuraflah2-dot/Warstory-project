import React from 'react';
import {Img, spring, staticFile, useVideoConfig} from 'remotion';
import {USE_PLACEHOLDER_ART} from './config.js';
import {PlaceholderCharacter, roleFromAsset, ROLE_SIZE} from './Placeholders.jsx';

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

// x,y = titik tengah-bawah (kaki) karakter di kanvas 1080x1920.
export const Character = ({
  asset,
  x = 540,
  y = 1330,
  scale = 1,
  opacity = 1,
  flip = false,
  expression = 'neutral',
  pose = 'stand',
  enter = 'none', // none | fade | pop | slide-left | slide-right | rise
  delay = 0,
  bob = 5,
  freeze = false,
  exit = null, // fall | slide-left | slide-right
  exitAt = null,
  exitDur = 18,
  frame = 0,
}) => {
  const {fps} = useVideoConfig();
  const role = roleFromAsset(asset);
  const [bw, bh] = ROLE_SIZE[role] || ROLE_SIZE.default;
  const w = bw * scale;
  const h = bh * scale;

  const sp = enter === 'none' ? 1 : clamp(spring({frame: frame - delay, fps, config: {damping: 14, stiffness: 110, mass: 0.8}}), 0, 1.2);
  const spc = clamp(sp, 0, 1);

  let dx = 0;
  let dy = 0;
  let sc = 1;
  let op = opacity;
  let rot = 0;

  if (enter === 'slide-left') { dx = (1 - sp) * -700; op *= clamp(spc * 3, 0, 1); }
  if (enter === 'slide-right') { dx = (1 - sp) * 700; op *= clamp(spc * 3, 0, 1); }
  if (enter === 'rise') { dy = (1 - sp) * 320; op *= clamp(spc * 3, 0, 1); }
  if (enter === 'fade') { op *= spc; }
  if (enter === 'pop') { sc = 0.55 + 0.45 * sp; op *= clamp(spc * 4, 0, 1); }

  if (exit && exitAt !== null) {
    const ex = clamp((frame - exitAt) / exitDur, 0, 1);
    if (exit === 'fall') { rot = ex * 80 * (flip ? -1 : 1); dy += ex * 90; op *= 1 - ex * 0.92; }
    if (exit === 'slide-left') { dx += -ex * 900; }
    if (exit === 'slide-right') { dx += ex * 900; }
  }

  const bobY = freeze ? 0 : Math.sin(frame / 9) * bob;
  const breathe = freeze ? 1 : 1 + Math.sin(frame / 20) * 0.008;
  const crouch = pose === 'crouch' ? 0.65 : 1;

  const style = {
    position: 'absolute',
    left: x - w / 2,
    top: y - h,
    width: w,
    height: h,
    opacity: op,
    transformOrigin: '50% 100%',
    transform: `translate(${dx}px, ${dy + bobY}px) rotate(${rot}deg) scale(${(flip ? -1 : 1) * sc * breathe}, ${sc * breathe * crouch})`,
  };

  return (
    <div style={style}>
      {USE_PLACEHOLDER_ART ? (
        <PlaceholderCharacter role={role} expression={expression} pose={pose} />
      ) : (
        <Img src={staticFile(asset.replace(/^\//, ''))} style={{width: '100%', height: '100%', objectFit: 'contain', objectPosition: 'bottom'}} />
      )}
    </div>
  );
};
