// FILE INI DIHASILKAN oleh tools/build_scenes.py dari public/audio/voiceover/timings.json.
// startFrame, durationInFrames dan start/end subtitle berasal dari timings.json (tidak dikarang).
// Pemetaan visual per segmen bisa diedit di tools/build_scenes.py lalu jalankan: npm run scenes

export const scenes = [
 {
  "id": "scene-01",
  "segment": 1,
  "startFrame": 0,
  "durationInFrames": 119,
  "holdFrames": 10,
  "visualDuration": 129,
  "lead": 0,
  "fadeOut": 0,
  "text": "Awalnya, prajurit ini bahkan tidak sanggup menembak musuh.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1560,
    "scale": 1.35,
    "expression": "fear",
    "pose": "aim",
    "bob": 4
   }
  ],
  "effects": {
   "vignette": 0.5
  },
  "voiceOver": "/audio/voiceover/segments/01.wav",
  "subtitles": [
   {
    "word": "Awalnya,",
    "start": 0.0,
    "end": 0.548
   },
   {
    "word": "prajurit",
    "start": 0.548,
    "end": 1.158
   },
   {
    "word": "ini",
    "start": 1.158,
    "end": 1.462
   },
   {
    "word": "bahkan",
    "start": 1.462,
    "end": 1.95
   },
   {
    "word": "tidak",
    "start": 1.95,
    "end": 2.376
   },
   {
    "word": "sanggup",
    "start": 2.376,
    "end": 2.924
   },
   {
    "word": "menembak",
    "start": 2.924,
    "end": 3.534
   },
   {
    "word": "musuh.",
    "start": 3.534,
    "end": 3.96
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 129,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1560,
      "scale": 1.35,
      "expression": "fear",
      "pose": "aim",
      "bob": 4
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.35
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      40
     ]
    },
    "effects": {
     "vignette": 0.5
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-02",
  "segment": 2,
  "startFrame": 129,
  "durationInFrames": 180,
  "holdFrames": 9,
  "visualDuration": 189,
  "lead": 0,
  "fadeOut": 0,
  "text": "Dia adalah anak baru yang ditempatkan di sebuah tank bersama sekelompok awak veteran.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 260,
    "y": 1530,
    "scale": 1.0,
    "expression": "fear",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 620,
    "y": 1520,
    "scale": 1.2,
    "expression": "neutral",
    "pose": "stand",
    "enter": "slide-right"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 900,
    "y": 1500,
    "scale": 1.1,
    "expression": "neutral",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.4
  },
  "voiceOver": "/audio/voiceover/segments/02.wav",
  "subtitles": [
   {
    "word": "Dia",
    "start": 4.292,
    "end": 4.598
   },
   {
    "word": "adalah",
    "start": 4.598,
    "end": 5.086
   },
   {
    "word": "anak",
    "start": 5.086,
    "end": 5.453
   },
   {
    "word": "baru",
    "start": 5.453,
    "end": 5.82
   },
   {
    "word": "yang",
    "start": 5.82,
    "end": 6.186
   },
   {
    "word": "ditempatkan",
    "start": 6.186,
    "end": 6.98
   },
   {
    "word": "di",
    "start": 6.98,
    "end": 7.225
   },
   {
    "word": "sebuah",
    "start": 7.225,
    "end": 7.714
   },
   {
    "word": "tank",
    "start": 7.714,
    "end": 8.08
   },
   {
    "word": "bersama",
    "start": 8.08,
    "end": 8.63
   },
   {
    "word": "sekelompok",
    "start": 8.63,
    "end": 9.363
   },
   {
    "word": "awak",
    "start": 9.363,
    "end": 9.73
   },
   {
    "word": "veteran.",
    "start": 9.73,
    "end": 10.28
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 95,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 260,
      "y": 1530,
      "scale": 1.0,
      "expression": "fear",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 620,
      "y": 1520,
      "scale": 1.2,
      "expression": "neutral",
      "pose": "stand",
      "enter": "slide-right"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 900,
      "y": 1500,
      "scale": 1.1,
      "expression": "neutral",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      -40
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.4
    },
    "transition": "cut"
   },
   {
    "offset": 95,
    "duration": 94,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 300,
      "y": 1570,
      "scale": 0.85,
      "expression": "fear",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 740,
      "y": 1570,
      "scale": 1.5,
      "expression": "grim",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.05,
      1.0
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.45
    },
    "transition": "fade"
   }
  ]
 },
 {
  "id": "scene-03",
  "segment": 3,
  "startFrame": 318,
  "durationInFrames": 93,
  "holdFrames": 13,
  "visualDuration": 106,
  "lead": 0,
  "fadeOut": 0,
  "text": "Di atas kertas, dia adalah seorang prajurit.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1540,
    "scale": 1.25,
    "expression": "neutral",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.35
  },
  "voiceOver": "/audio/voiceover/segments/03.wav",
  "subtitles": [
   {
    "word": "Di",
    "start": 10.591,
    "end": 10.84
   },
   {
    "word": "atas",
    "start": 10.84,
    "end": 11.213
   },
   {
    "word": "kertas,",
    "start": 11.213,
    "end": 11.71
   },
   {
    "word": "dia",
    "start": 11.71,
    "end": 12.021
   },
   {
    "word": "adalah",
    "start": 12.021,
    "end": 12.518
   },
   {
    "word": "seorang",
    "start": 12.518,
    "end": 13.077
   },
   {
    "word": "prajurit.",
    "start": 13.077,
    "end": 13.699
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 106,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1540,
      "scale": 1.25,
      "expression": "neutral",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.2,
      1.0
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.35
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-04",
  "segment": 4,
  "startFrame": 424,
  "durationInFrames": 41,
  "holdFrames": 12,
  "visualDuration": 53,
  "lead": 0,
  "fadeOut": 0,
  "text": "Tapi di medan perang...",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1540,
    "scale": 1.3,
    "expression": "sad",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.6,
   "tint": "rgba(8,10,22,0.38)"
  },
  "voiceOver": "/audio/voiceover/segments/04.wav",
  "subtitles": [
   {
    "word": "Tapi",
    "start": 14.132,
    "end": 14.462
   },
   {
    "word": "di",
    "start": 14.462,
    "end": 14.682
   },
   {
    "word": "medan",
    "start": 14.682,
    "end": 15.066
   },
   {
    "word": "perang...",
    "start": 15.066,
    "end": 15.506
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 53,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1540,
      "scale": 1.3,
      "expression": "sad",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.2
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.6,
     "tint": "rgba(8,10,22,0.38)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-05",
  "segment": 5,
  "startFrame": 477,
  "durationInFrames": 74,
  "holdFrames": 10,
  "visualDuration": 84,
  "lead": 0,
  "fadeOut": 0,
  "text": "dia bahkan belum siap untuk membunuh.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1580,
    "scale": 1.6,
    "expression": "fear",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.6
  },
  "voiceOver": "/audio/voiceover/segments/05.wav",
  "subtitles": [
   {
    "word": "dia",
    "start": 15.905,
    "end": 16.191
   },
   {
    "word": "bahkan",
    "start": 16.191,
    "end": 16.649
   },
   {
    "word": "belum",
    "start": 16.649,
    "end": 17.049
   },
   {
    "word": "siap",
    "start": 17.049,
    "end": 17.392
   },
   {
    "word": "untuk",
    "start": 17.392,
    "end": 17.793
   },
   {
    "word": "membunuh.",
    "start": 17.793,
    "end": 18.365
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 84,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1580,
      "scale": 1.6,
      "expression": "fear",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.1,
      1.4
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      35
     ]
    },
    "effects": {
     "vignette": 0.6
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-06",
  "segment": 6,
  "startFrame": 561,
  "durationInFrames": 91,
  "holdFrames": 11,
  "visualDuration": 102,
  "lead": 8,
  "fadeOut": 0,
  "text": "Setiap kali musuh muncul, dia ragu.",
  "background": "/backgrounds/battlefield.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 260,
    "y": 1560,
    "scale": 1.2,
    "expression": "fear",
    "pose": "aim"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 760,
    "y": 1250,
    "scale": 0.7,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 910,
    "y": 1310,
    "scale": 0.9,
    "expression": "neutral",
    "pose": "stand",
    "enter": "rise",
    "delay": 15
   }
  ],
  "effects": {
   "vignette": 0.4,
   "dust": 0.5
  },
  "voiceOver": "/audio/voiceover/segments/06.wav",
  "subtitles": [
   {
    "word": "Setiap",
    "start": 18.697,
    "end": 19.306
   },
   {
    "word": "kali",
    "start": 19.306,
    "end": 19.762
   },
   {
    "word": "musuh",
    "start": 19.762,
    "end": 20.295
   },
   {
    "word": "muncul,",
    "start": 20.295,
    "end": 20.904
   },
   {
    "word": "dia",
    "start": 20.904,
    "end": 21.284
   },
   {
    "word": "ragu.",
    "start": 21.284,
    "end": 21.741
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 102,
    "background": "/backgrounds/battlefield.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 260,
      "y": 1560,
      "scale": 1.2,
      "expression": "fear",
      "pose": "aim"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 760,
      "y": 1250,
      "scale": 0.7,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 910,
      "y": 1310,
      "scale": 0.9,
      "expression": "neutral",
      "pose": "stand",
      "enter": "rise",
      "delay": 15
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.05
     ],
     "panX": [
      0,
      -40
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.4,
     "dust": 0.5
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-07",
  "segment": 7,
  "startFrame": 663,
  "durationInFrames": 122,
  "holdFrames": 9,
  "visualDuration": 131,
  "lead": 0,
  "fadeOut": 0,
  "text": "Saat diperintahkan untuk menembak, tangannya membeku.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 400,
    "y": 1500,
    "scale": 1.4,
    "expression": "fear",
    "pose": "aim"
   }
  ],
  "effects": {
   "vignette": 0.7,
   "shake": 1.2
  },
  "voiceOver": "/audio/voiceover/segments/07.wav",
  "subtitles": [
   {
    "word": "Saat",
    "start": 22.115,
    "end": 22.534
   },
   {
    "word": "diperintahkan",
    "start": 22.534,
    "end": 23.583
   },
   {
    "word": "untuk",
    "start": 23.583,
    "end": 24.072
   },
   {
    "word": "menembak,",
    "start": 24.072,
    "end": 24.771
   },
   {
    "word": "tangannya",
    "start": 24.771,
    "end": 25.54
   },
   {
    "word": "membeku.",
    "start": 25.54,
    "end": 26.169
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 50,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 400,
      "y": 1500,
      "scale": 1.4,
      "expression": "fear",
      "pose": "aim"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      2.5
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      52,
      61
     ]
    },
    "effects": {
     "vignette": 0.7,
     "shake": 1.2
    },
    "transition": "cut"
   },
   {
    "offset": 50,
    "duration": 81,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 400,
      "y": 1500,
      "scale": 1.4,
      "expression": "fear",
      "pose": "aim",
      "freeze": true
     }
    ],
    "camera": {
     "zoom": [
      2.5,
      2.7
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      52,
      61
     ]
    },
    "effects": {
     "vignette": 0.75,
     "shake": 0.3
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-08",
  "segment": 8,
  "startFrame": 794,
  "durationInFrames": 197,
  "holdFrames": 9,
  "visualDuration": 206,
  "lead": 0,
  "fadeOut": 0,
  "text": "Bagi para veteran di dalam tank itu, keraguan seperti ini bisa membunuh seluruh kru.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/veteran-crew.png",
    "x": 200,
    "y": 1520,
    "scale": 1.15,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 880,
    "y": 1520,
    "scale": 1.15,
    "expression": "grim",
    "pose": "stand",
    "flip": true
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1590,
    "scale": 0.8,
    "expression": "fear",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.45
  },
  "voiceOver": "/audio/voiceover/segments/08.wav",
  "subtitles": [
   {
    "word": "Bagi",
    "start": 26.468,
    "end": 26.873
   },
   {
    "word": "para",
    "start": 26.873,
    "end": 27.279
   },
   {
    "word": "veteran",
    "start": 27.279,
    "end": 27.887
   },
   {
    "word": "di",
    "start": 27.887,
    "end": 28.157
   },
   {
    "word": "dalam",
    "start": 28.157,
    "end": 28.63
   },
   {
    "word": "tank",
    "start": 28.63,
    "end": 29.036
   },
   {
    "word": "itu,",
    "start": 29.036,
    "end": 29.374
   },
   {
    "word": "keraguan",
    "start": 29.374,
    "end": 30.05
   },
   {
    "word": "seperti",
    "start": 30.05,
    "end": 30.658
   },
   {
    "word": "ini",
    "start": 30.658,
    "end": 30.996
   },
   {
    "word": "bisa",
    "start": 30.996,
    "end": 31.401
   },
   {
    "word": "membunuh",
    "start": 31.401,
    "end": 32.077
   },
   {
    "word": "seluruh",
    "start": 32.077,
    "end": 32.685
   },
   {
    "word": "kru.",
    "start": 32.685,
    "end": 33.023
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 100,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/veteran-crew.png",
      "x": 200,
      "y": 1520,
      "scale": 1.15,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 880,
      "y": 1520,
      "scale": 1.15,
      "expression": "grim",
      "pose": "stand",
      "flip": true
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1590,
      "scale": 0.8,
      "expression": "fear",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.05
     ],
     "panX": [
      0,
      -40
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.45
    },
    "transition": "cut"
   },
   {
    "offset": 100,
    "duration": 106,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/veteran-crew.png",
      "x": 540,
      "y": 1610,
      "scale": 1.9,
      "expression": "grim",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.55
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-09",
  "segment": 9,
  "startFrame": 1000,
  "durationInFrames": 52,
  "holdFrames": 14,
  "visualDuration": 66,
  "lead": 0,
  "fadeOut": 0,
  "text": "Dan komandan tank ini tahu...",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 540,
    "y": 1540,
    "scale": 1.4,
    "expression": "grim",
    "pose": "stand",
    "enter": "pop"
   }
  ],
  "effects": {
   "vignette": 0.5
  },
  "voiceOver": "/audio/voiceover/segments/09.wav",
  "subtitles": [
   {
    "word": "Dan",
    "start": 33.332,
    "end": 33.601
   },
   {
    "word": "komandan",
    "start": 33.601,
    "end": 34.138
   },
   {
    "word": "tank",
    "start": 34.138,
    "end": 34.46
   },
   {
    "word": "ini",
    "start": 34.46,
    "end": 34.729
   },
   {
    "word": "tahu...",
    "start": 34.729,
    "end": 35.051
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 66,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 540,
      "y": 1540,
      "scale": 1.4,
      "expression": "grim",
      "pose": "stand",
      "enter": "pop"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.2
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-10",
  "segment": 10,
  "startFrame": 1066,
  "durationInFrames": 131,
  "holdFrames": 12,
  "visualDuration": 143,
  "lead": 0,
  "fadeOut": 0,
  "text": "kalau prajurit baru itu ingin bertahan hidup, dia harus berubah.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 760,
    "y": 1540,
    "scale": 1.3,
    "expression": "grim",
    "pose": "stand",
    "flip": true
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 300,
    "y": 1570,
    "scale": 1.0,
    "expression": "fear",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.45
  },
  "voiceOver": "/audio/voiceover/segments/10.wav",
  "subtitles": [
   {
    "word": "kalau",
    "start": 35.534,
    "end": 35.952
   },
   {
    "word": "prajurit",
    "start": 35.952,
    "end": 36.548
   },
   {
    "word": "baru",
    "start": 36.548,
    "end": 36.906
   },
   {
    "word": "itu",
    "start": 36.906,
    "end": 37.204
   },
   {
    "word": "ingin",
    "start": 37.204,
    "end": 37.622
   },
   {
    "word": "bertahan",
    "start": 37.622,
    "end": 38.218
   },
   {
    "word": "hidup,",
    "start": 38.218,
    "end": 38.635
   },
   {
    "word": "dia",
    "start": 38.635,
    "end": 38.934
   },
   {
    "word": "harus",
    "start": 38.934,
    "end": 39.351
   },
   {
    "word": "berubah.",
    "start": 39.351,
    "end": 39.888
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 70,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 760,
      "y": 1540,
      "scale": 1.3,
      "expression": "grim",
      "pose": "stand",
      "flip": true
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 300,
      "y": 1570,
      "scale": 1.0,
      "expression": "fear",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.05
     ],
     "panX": [
      0,
      30
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.45
    },
    "transition": "cut"
   },
   {
    "offset": 70,
    "duration": 73,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1590,
      "scale": 1.5,
      "expression": "resolve",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.1,
      1.35
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.55
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-11",
  "segment": 11,
  "startFrame": 1209,
  "durationInFrames": 78,
  "holdFrames": 10,
  "visualDuration": 88,
  "lead": 0,
  "fadeOut": 0,
  "text": "Komandan ini tidak memberinya waktu untuk takut.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 300,
    "y": 1540,
    "scale": 1.4,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 780,
    "y": 1580,
    "scale": 1.05,
    "expression": "fear",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.5,
   "shake": 0.5
  },
  "voiceOver": "/audio/voiceover/segments/11.wav",
  "subtitles": [
   {
    "word": "Komandan",
    "start": 40.314,
    "end": 40.787
   },
   {
    "word": "ini",
    "start": 40.787,
    "end": 41.024
   },
   {
    "word": "tidak",
    "start": 41.024,
    "end": 41.355
   },
   {
    "word": "memberinya",
    "start": 41.355,
    "end": 41.923
   },
   {
    "word": "waktu",
    "start": 41.923,
    "end": 42.254
   },
   {
    "word": "untuk",
    "start": 42.254,
    "end": 42.586
   },
   {
    "word": "takut.",
    "start": 42.586,
    "end": 42.917
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 88,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 300,
      "y": 1540,
      "scale": 1.4,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 780,
      "y": 1580,
      "scale": 1.05,
      "expression": "fear",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      30,
      50
     ]
    },
    "effects": {
     "vignette": 0.5,
     "shake": 0.5
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-12",
  "segment": 12,
  "startFrame": 1297,
  "durationInFrames": 99,
  "holdFrames": 12,
  "visualDuration": 111,
  "lead": 8,
  "fadeOut": 0,
  "text": "Dia memaksanya melihat perang sebagaimana adanya.",
  "background": "/backgrounds/battlefield.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 280,
    "y": 1540,
    "scale": 1.25,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 720,
    "y": 1560,
    "scale": 1.1,
    "expression": "shock",
    "pose": "stand"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 860,
    "y": 1220,
    "scale": 0.65,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade",
    "delay": 20
   }
  ],
  "effects": {
   "vignette": 0.5,
   "dust": 0.8,
   "smoke": 0.5,
   "shakePulses": [
    30,
    60
   ],
   "pulseAmp": 6
  },
  "voiceOver": "/audio/voiceover/segments/12.wav",
  "subtitles": [
   {
    "word": "Dia",
    "start": 43.223,
    "end": 43.522
   },
   {
    "word": "memaksanya",
    "start": 43.522,
    "end": 44.239
   },
   {
    "word": "melihat",
    "start": 44.239,
    "end": 44.777
   },
   {
    "word": "perang",
    "start": 44.777,
    "end": 45.256
   },
   {
    "word": "sebagaimana",
    "start": 45.256,
    "end": 46.033
   },
   {
    "word": "adanya.",
    "start": 46.033,
    "end": 46.511
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 111,
    "background": "/backgrounds/battlefield.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 280,
      "y": 1540,
      "scale": 1.25,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 720,
      "y": 1560,
      "scale": 1.1,
      "expression": "shock",
      "pose": "stand"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 860,
      "y": 1220,
      "scale": 0.65,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 20
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.2
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "dust": 0.8,
     "smoke": 0.5,
     "shakePulses": [
      30,
      60
     ],
     "pulseAmp": 6
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-13",
  "segment": 13,
  "startFrame": 1408,
  "durationInFrames": 53,
  "holdFrames": 13,
  "visualDuration": 66,
  "lead": 0,
  "fadeOut": 0,
  "text": "Tidak ada pilihan yang mudah.",
  "background": "/backgrounds/battlefield.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1560,
    "scale": 1.4,
    "expression": "fear",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.5,
   "smoke": 0.6,
   "dust": 0.5
  },
  "voiceOver": "/audio/voiceover/segments/13.wav",
  "subtitles": [
   {
    "word": "Tidak",
    "start": 46.929,
    "end": 47.29
   },
   {
    "word": "ada",
    "start": 47.29,
    "end": 47.548
   },
   {
    "word": "pilihan",
    "start": 47.548,
    "end": 48.012
   },
   {
    "word": "yang",
    "start": 48.012,
    "end": 48.322
   },
   {
    "word": "mudah.",
    "start": 48.322,
    "end": 48.683
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 66,
    "background": "/backgrounds/battlefield.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1560,
      "scale": 1.4,
      "expression": "fear",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.05,
      1.1
     ],
     "panX": [
      0,
      -30
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "smoke": 0.6,
     "dust": 0.5
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-14",
  "segment": 14,
  "startFrame": 1474,
  "durationInFrames": 69,
  "holdFrames": 13,
  "visualDuration": 82,
  "lead": 0,
  "fadeOut": 0,
  "text": "Tidak ada tempat untuk bersembunyi.",
  "background": "/backgrounds/battlefield.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1500,
    "scale": 0.8,
    "expression": "fear",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.55,
   "dust": 0.6
  },
  "voiceOver": "/audio/voiceover/segments/14.wav",
  "subtitles": [
   {
    "word": "Tidak",
    "start": 49.146,
    "end": 49.548
   },
   {
    "word": "ada",
    "start": 49.548,
    "end": 49.836
   },
   {
    "word": "tempat",
    "start": 49.836,
    "end": 50.296
   },
   {
    "word": "untuk",
    "start": 50.296,
    "end": 50.698
   },
   {
    "word": "bersembunyi.",
    "start": 50.698,
    "end": 51.446
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 82,
    "background": "/backgrounds/battlefield.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1500,
      "scale": 0.8,
      "expression": "fear",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.3,
      1.0
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      70
     ]
    },
    "effects": {
     "vignette": 0.55,
     "dust": 0.6
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-15",
  "segment": 15,
  "startFrame": 1556,
  "durationInFrames": 32,
  "holdFrames": 9,
  "visualDuration": 41,
  "lead": 8,
  "fadeOut": 0,
  "text": "Dan perlahan...",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1560,
    "scale": 1.3,
    "expression": "tired",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.5,
   "tint": "rgba(20,40,70,0.15)"
  },
  "voiceOver": "/audio/voiceover/segments/15.wav",
  "subtitles": [
   {
    "word": "Dan",
    "start": 51.855,
    "end": 52.206
   },
   {
    "word": "perlahan...",
    "start": 52.206,
    "end": 52.908
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 41,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1560,
      "scale": 1.3,
      "expression": "tired",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.12
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "tint": "rgba(20,40,70,0.15)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-16",
  "segment": 16,
  "startFrame": 1597,
  "durationInFrames": 179,
  "holdFrames": 5,
  "visualDuration": 184,
  "lead": 0,
  "fadeOut": 0,
  "text": "prajurit yang awalnya tidak sanggup menarik pelatuk itu mulai berubah.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1560,
    "scale": 1.35,
    "expression": "fear",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.5
  },
  "voiceOver": "/audio/voiceover/segments/16.wav",
  "subtitles": [
   {
    "word": "prajurit",
    "start": 53.227,
    "end": 53.973
   },
   {
    "word": "yang",
    "start": 53.973,
    "end": 54.421
   },
   {
    "word": "awalnya",
    "start": 54.421,
    "end": 55.092
   },
   {
    "word": "tidak",
    "start": 55.092,
    "end": 55.615
   },
   {
    "word": "sanggup",
    "start": 55.615,
    "end": 56.286
   },
   {
    "word": "menarik",
    "start": 56.286,
    "end": 56.958
   },
   {
    "word": "pelatuk",
    "start": 56.958,
    "end": 57.629
   },
   {
    "word": "itu",
    "start": 57.629,
    "end": 58.002
   },
   {
    "word": "mulai",
    "start": 58.002,
    "end": 58.524
   },
   {
    "word": "berubah.",
    "start": 58.524,
    "end": 59.196
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 85,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1560,
      "scale": 1.35,
      "expression": "fear",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.2
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5
    },
    "transition": "cut"
   },
   {
    "offset": 85,
    "duration": 99,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 400,
      "y": 1560,
      "scale": 1.3,
      "expression": "resolve",
      "pose": "aim"
     },
     {
      "asset": "/characters/tank-commander.png",
      "x": 820,
      "y": 1540,
      "scale": 1.1,
      "expression": "grim",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.1,
      1.0
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.45
    },
    "transition": "fade"
   }
  ]
 },
 {
  "id": "scene-17",
  "segment": 17,
  "startFrame": 1781,
  "durationInFrames": 32,
  "holdFrames": 11,
  "visualDuration": 43,
  "lead": 0,
  "fadeOut": 0,
  "text": "Dia mulai menembak.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1520,
    "scale": 1.4,
    "expression": "resolve",
    "pose": "aim"
   }
  ],
  "effects": {
   "vignette": 0.5,
   "muzzle": [
    4
   ],
   "muzzleAt": [
    74,
    61
   ],
   "flash": [
    4
   ],
   "shakePulses": [
    4
   ],
   "pulseAmp": 22
  },
  "voiceOver": "/audio/voiceover/segments/17.wav",
  "subtitles": [
   {
    "word": "Dia",
    "start": 59.374,
    "end": 59.616
   },
   {
    "word": "mulai",
    "start": 59.616,
    "end": 59.954
   },
   {
    "word": "menembak.",
    "start": 59.954,
    "end": 60.438
   }
  ],
  "sfx": [
   {
    "name": "gunfire",
    "at": 4,
    "volume": 0.5
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 43,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1520,
      "scale": 1.4,
      "expression": "resolve",
      "pose": "aim"
     }
    ],
    "camera": {
     "zoom": [
      1.1,
      1.2
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "muzzle": [
      4
     ],
     "muzzleAt": [
      74,
      61
     ],
     "flash": [
      4
     ],
     "shakePulses": [
      4
     ],
     "pulseAmp": 22
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-18",
  "segment": 18,
  "startFrame": 1824,
  "durationInFrames": 33,
  "holdFrames": 11,
  "visualDuration": 44,
  "lead": 0,
  "fadeOut": 0,
  "text": "Mulai membunuh.",
  "background": "/backgrounds/battlefield.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 300,
    "y": 1540,
    "scale": 1.2,
    "expression": "resolve",
    "pose": "aim"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 780,
    "y": 1250,
    "scale": 0.6,
    "expression": "neutral",
    "pose": "stand",
    "exit": "fall",
    "exitAt": 10,
    "exitDur": 16
   }
  ],
  "effects": {
   "vignette": 0.5,
   "muzzle": [
    3
   ],
   "muzzleAt": [
    48,
    64
   ],
   "shakePulses": [
    3
   ],
   "pulseAmp": 14,
   "dust": 0.4
  },
  "voiceOver": "/audio/voiceover/segments/18.wav",
  "subtitles": [
   {
    "word": "Mulai",
    "start": 60.798,
    "end": 61.244
   },
   {
    "word": "membunuh.",
    "start": 61.244,
    "end": 61.882
   }
  ],
  "sfx": [
   {
    "name": "gunfire",
    "at": 3,
    "volume": 0.45
   },
   {
    "name": "bullet-impact",
    "at": 10,
    "volume": 0.35
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 44,
    "background": "/backgrounds/battlefield.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 300,
      "y": 1540,
      "scale": 1.2,
      "expression": "resolve",
      "pose": "aim"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 780,
      "y": 1250,
      "scale": 0.6,
      "expression": "neutral",
      "pose": "stand",
      "exit": "fall",
      "exitAt": 10,
      "exitDur": 16
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "muzzle": [
      3
     ],
     "muzzleAt": [
      48,
      64
     ],
     "shakePulses": [
      3
     ],
     "pulseAmp": 14,
     "dust": 0.4
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-19",
  "segment": 19,
  "startFrame": 1868,
  "durationInFrames": 178,
  "holdFrames": 12,
  "visualDuration": 190,
  "lead": 0,
  "fadeOut": 0,
  "text": "Dan mulai memahami bahwa di medan perang, terlambat mengambil keputusan bisa berarti kematian.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1560,
    "scale": 1.3,
    "expression": "resolve",
    "pose": "stand"
   },
   {
    "asset": "/characters/tank-commander.png",
    "x": 250,
    "y": 1540,
    "scale": 1.1,
    "expression": "grim",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.5
  },
  "voiceOver": "/audio/voiceover/segments/19.wav",
  "subtitles": [
   {
    "word": "Dan",
    "start": 62.25,
    "end": 62.53
   },
   {
    "word": "mulai",
    "start": 62.53,
    "end": 62.922
   },
   {
    "word": "memahami",
    "start": 62.922,
    "end": 63.481
   },
   {
    "word": "bahwa",
    "start": 63.481,
    "end": 63.873
   },
   {
    "word": "di",
    "start": 63.873,
    "end": 64.097
   },
   {
    "word": "medan",
    "start": 64.097,
    "end": 64.488
   },
   {
    "word": "perang,",
    "start": 64.488,
    "end": 64.936
   },
   {
    "word": "terlambat",
    "start": 64.936,
    "end": 65.552
   },
   {
    "word": "mengambil",
    "start": 65.552,
    "end": 66.167
   },
   {
    "word": "keputusan",
    "start": 66.167,
    "end": 66.783
   },
   {
    "word": "bisa",
    "start": 66.783,
    "end": 67.119
   },
   {
    "word": "berarti",
    "start": 67.119,
    "end": 67.622
   },
   {
    "word": "kematian.",
    "start": 67.622,
    "end": 68.182
   }
  ],
  "sfx": [
   {
    "name": "gunfire",
    "at": 100,
    "volume": 0.4
   },
   {
    "name": "gunfire",
    "at": 120,
    "volume": 0.4
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 90,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1560,
      "scale": 1.3,
      "expression": "resolve",
      "pose": "stand"
     },
     {
      "asset": "/characters/tank-commander.png",
      "x": 250,
      "y": 1540,
      "scale": 1.1,
      "expression": "grim",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5
    },
    "transition": "cut"
   },
   {
    "offset": 90,
    "duration": 100,
    "background": "/backgrounds/battlefield.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 280,
      "y": 1540,
      "scale": 1.2,
      "expression": "resolve",
      "pose": "aim"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 760,
      "y": 1340,
      "scale": 1.3,
      "expression": "neutral",
      "pose": "stand",
      "enter": "rise"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.2
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "dust": 0.6,
     "muzzle": [
      10,
      30
     ],
     "muzzleAt": [
      46,
      64
     ],
     "shakePulses": [
      10,
      30
     ],
     "pulseAmp": 8
    },
    "transition": "fade"
   }
  ]
 },
 {
  "id": "scene-20",
  "segment": 20,
  "startFrame": 2058,
  "durationInFrames": 110,
  "holdFrames": 9,
  "visualDuration": 119,
  "lead": 8,
  "fadeOut": 0,
  "text": "Seiring waktu, dia tidak lagi dianggap sebagai beban.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1560,
    "scale": 1.2,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 880,
    "y": 1520,
    "scale": 1.15,
    "expression": "neutral",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.4,
   "tint": "rgba(255,170,70,0.10)"
  },
  "voiceOver": "/audio/voiceover/segments/20.wav",
  "subtitles": [
   {
    "word": "Seiring",
    "start": 68.597,
    "end": 69.147
   },
   {
    "word": "waktu,",
    "start": 69.147,
    "end": 69.575
   },
   {
    "word": "dia",
    "start": 69.575,
    "end": 69.881
   },
   {
    "word": "tidak",
    "start": 69.881,
    "end": 70.309
   },
   {
    "word": "lagi",
    "start": 70.309,
    "end": 70.676
   },
   {
    "word": "dianggap",
    "start": 70.676,
    "end": 71.288
   },
   {
    "word": "sebagai",
    "start": 71.288,
    "end": 71.838
   },
   {
    "word": "beban.",
    "start": 71.838,
    "end": 72.266
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 119,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1560,
      "scale": 1.2,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 880,
      "y": 1520,
      "scale": 1.15,
      "expression": "neutral",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.4,
     "tint": "rgba(255,170,70,0.10)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-21",
  "segment": 21,
  "startFrame": 2177,
  "durationInFrames": 83,
  "holdFrames": 13,
  "visualDuration": 96,
  "lead": 0,
  "fadeOut": 0,
  "text": "Dia mulai diterima sebagai bagian dari kru.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 380,
    "y": 1560,
    "scale": 1.15,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 760,
    "y": 1520,
    "scale": 1.2,
    "expression": "neutral",
    "pose": "stand",
    "flip": true,
    "enter": "pop"
   }
  ],
  "effects": {
   "vignette": 0.4,
   "tint": "rgba(255,170,70,0.10)"
  },
  "voiceOver": "/audio/voiceover/segments/21.wav",
  "subtitles": [
   {
    "word": "Dia",
    "start": 72.581,
    "end": 72.859
   },
   {
    "word": "mulai",
    "start": 72.859,
    "end": 73.248
   },
   {
    "word": "diterima",
    "start": 73.248,
    "end": 73.804
   },
   {
    "word": "sebagai",
    "start": 73.804,
    "end": 74.305
   },
   {
    "word": "bagian",
    "start": 74.305,
    "end": 74.749
   },
   {
    "word": "dari",
    "start": 74.749,
    "end": 75.083
   },
   {
    "word": "kru.",
    "start": 75.083,
    "end": 75.361
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 96,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 380,
      "y": 1560,
      "scale": 1.15,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 760,
      "y": 1520,
      "scale": 1.2,
      "expression": "neutral",
      "pose": "stand",
      "flip": true,
      "enter": "pop"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.08
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.4,
     "tint": "rgba(255,170,70,0.10)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-22",
  "segment": 22,
  "startFrame": 2273,
  "durationInFrames": 50,
  "holdFrames": 9,
  "visualDuration": 59,
  "lead": 0,
  "fadeOut": 0,
  "text": "Mereka bertempur bersama.",
  "background": "/backgrounds/battlefield.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 250,
    "y": 1540,
    "scale": 1.1,
    "expression": "resolve",
    "pose": "aim"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 540,
    "y": 1520,
    "scale": 1.15,
    "expression": "resolve",
    "pose": "aim"
   },
   {
    "asset": "/characters/tank-commander.png",
    "x": 830,
    "y": 1520,
    "scale": 1.15,
    "expression": "grim",
    "pose": "aim",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.45,
   "muzzle": [
    8,
    26,
    40
   ],
   "muzzleAt": [
    34,
    63
   ],
   "shakePulses": [
    8,
    26,
    40
   ],
   "pulseAmp": 7,
   "dust": 0.4
  },
  "voiceOver": "/audio/voiceover/segments/22.wav",
  "subtitles": [
   {
    "word": "Mereka",
    "start": 75.781,
    "end": 76.253
   },
   {
    "word": "bertempur",
    "start": 76.253,
    "end": 76.903
   },
   {
    "word": "bersama.",
    "start": 76.903,
    "end": 77.434
   }
  ],
  "sfx": [
   {
    "name": "gunfire",
    "at": 8,
    "volume": 0.4
   },
   {
    "name": "gunfire",
    "at": 26,
    "volume": 0.4
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 59,
    "background": "/backgrounds/battlefield.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 250,
      "y": 1540,
      "scale": 1.1,
      "expression": "resolve",
      "pose": "aim"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 540,
      "y": 1520,
      "scale": 1.15,
      "expression": "resolve",
      "pose": "aim"
     },
     {
      "asset": "/characters/tank-commander.png",
      "x": 830,
      "y": 1520,
      "scale": 1.15,
      "expression": "grim",
      "pose": "aim",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.08
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.45,
     "muzzle": [
      8,
      26,
      40
     ],
     "muzzleAt": [
      34,
      63
     ],
     "shakePulses": [
      8,
      26,
      40
     ],
     "pulseAmp": 7,
     "dust": 0.4
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-23",
  "segment": 23,
  "startFrame": 2332,
  "durationInFrames": 34,
  "holdFrames": 14,
  "visualDuration": 48,
  "lead": 0,
  "fadeOut": 0,
  "text": "Makan bersama.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 300,
    "y": 1560,
    "scale": 1.1,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 620,
    "y": 1520,
    "scale": 1.15,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/tank-commander.png",
    "x": 900,
    "y": 1520,
    "scale": 1.1,
    "expression": "neutral",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.4,
   "tint": "rgba(255,170,70,0.10)"
  },
  "voiceOver": "/audio/voiceover/segments/23.wav",
  "subtitles": [
   {
    "word": "Makan",
    "start": 77.738,
    "end": 78.241
   },
   {
    "word": "bersama.",
    "start": 78.241,
    "end": 78.888
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 48,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 300,
      "y": 1560,
      "scale": 1.1,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 620,
      "y": 1520,
      "scale": 1.15,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/tank-commander.png",
      "x": 900,
      "y": 1520,
      "scale": 1.1,
      "expression": "neutral",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.04
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.4,
     "tint": "rgba(255,170,70,0.10)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-24",
  "segment": 24,
  "startFrame": 2380,
  "durationInFrames": 73,
  "holdFrames": 11,
  "visualDuration": 84,
  "lead": 0,
  "fadeOut": 0,
  "text": "Dan saling bergantung untuk tetap hidup.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 250,
    "y": 1570,
    "scale": 1.0,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 500,
    "y": 1530,
    "scale": 1.05,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/tank-commander.png",
    "x": 780,
    "y": 1530,
    "scale": 1.05,
    "expression": "neutral",
    "pose": "stand",
    "flip": true
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 1000,
    "y": 1540,
    "scale": 0.95,
    "expression": "neutral",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.45,
   "tint": "rgba(255,170,70,0.10)"
  },
  "voiceOver": "/audio/voiceover/segments/24.wav",
  "subtitles": [
   {
    "word": "Dan",
    "start": 79.333,
    "end": 79.599
   },
   {
    "word": "saling",
    "start": 79.599,
    "end": 80.024
   },
   {
    "word": "bergantung",
    "start": 80.024,
    "end": 80.661
   },
   {
    "word": "untuk",
    "start": 80.661,
    "end": 81.033
   },
   {
    "word": "tetap",
    "start": 81.033,
    "end": 81.405
   },
   {
    "word": "hidup.",
    "start": 81.405,
    "end": 81.777
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 84,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 250,
      "y": 1570,
      "scale": 1.0,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 500,
      "y": 1530,
      "scale": 1.05,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/tank-commander.png",
      "x": 780,
      "y": 1530,
      "scale": 1.05,
      "expression": "neutral",
      "pose": "stand",
      "flip": true
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 1000,
      "y": 1540,
      "scale": 0.95,
      "expression": "neutral",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.45,
     "tint": "rgba(255,170,70,0.10)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-25",
  "segment": 25,
  "startFrame": 2464,
  "durationInFrames": 38,
  "holdFrames": 15,
  "visualDuration": 53,
  "lead": 8,
  "fadeOut": 0,
  "text": "Sampai akhirnya...",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank.png",
    "x": 540,
    "y": 1500,
    "scale": 0.9,
    "expression": "neutral",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.4,
   "dust": 0.4
  },
  "voiceOver": "/audio/voiceover/segments/25.wav",
  "subtitles": [
   {
    "word": "Sampai",
    "start": 82.127,
    "end": 82.695
   },
   {
    "word": "akhirnya...",
    "start": 82.695,
    "end": 83.404
   }
  ],
  "sfx": [
   {
    "name": "tank-engine",
    "at": 0,
    "volume": 0.35
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 53,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank.png",
      "x": 540,
      "y": 1500,
      "scale": 0.9,
      "expression": "neutral",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.4,
     "dust": 0.4
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-26",
  "segment": 26,
  "startFrame": 2517,
  "durationInFrames": 108,
  "holdFrames": 9,
  "visualDuration": 117,
  "lead": 0,
  "fadeOut": 0,
  "text": "mereka mendapatkan sebuah misi yang terlihat sederhana.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank.png",
    "x": 540,
    "y": 1380,
    "scale": 0.7,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/tank-commander.png",
    "x": 280,
    "y": 1570,
    "scale": 1.2,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 760,
    "y": 1590,
    "scale": 1.1,
    "expression": "neutral",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.4,
   "dust": 0.4
  },
  "voiceOver": "/audio/voiceover/segments/26.wav",
  "subtitles": [
   {
    "word": "mereka",
    "start": 83.91,
    "end": 84.377
   },
   {
    "word": "mendapatkan",
    "start": 84.377,
    "end": 85.135
   },
   {
    "word": "sebuah",
    "start": 85.135,
    "end": 85.601
   },
   {
    "word": "misi",
    "start": 85.601,
    "end": 85.951
   },
   {
    "word": "yang",
    "start": 85.951,
    "end": 86.301
   },
   {
    "word": "terlihat",
    "start": 86.301,
    "end": 86.884
   },
   {
    "word": "sederhana.",
    "start": 86.884,
    "end": 87.526
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 117,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank.png",
      "x": 540,
      "y": 1380,
      "scale": 0.7,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/tank-commander.png",
      "x": 280,
      "y": 1570,
      "scale": 1.2,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 760,
      "y": 1590,
      "scale": 1.1,
      "expression": "neutral",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.08
     ],
     "panX": [
      0,
      -30
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.4,
     "dust": 0.4
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-27",
  "segment": 27,
  "startFrame": 2634,
  "durationInFrames": 132,
  "holdFrames": 6,
  "visualDuration": 138,
  "lead": 0,
  "fadeOut": 0,
  "text": "Mereka diperintahkan untuk mempertahankan sebuah persimpangan.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank.png",
    "x": 540,
    "y": 1480,
    "scale": 1.1,
    "expression": "neutral",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.45,
   "dust": 0.4
  },
  "voiceOver": "/audio/voiceover/segments/27.wav",
  "subtitles": [
   {
    "word": "Mereka",
    "start": 87.803,
    "end": 88.32
   },
   {
    "word": "diperintahkan",
    "start": 88.32,
    "end": 89.291
   },
   {
    "word": "untuk",
    "start": 89.291,
    "end": 89.743
   },
   {
    "word": "mempertahankan",
    "start": 89.743,
    "end": 90.778
   },
   {
    "word": "sebuah",
    "start": 90.778,
    "end": 91.296
   },
   {
    "word": "persimpangan.",
    "start": 91.296,
    "end": 92.201
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 65,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank.png",
      "x": 540,
      "y": 1480,
      "scale": 1.1,
      "expression": "neutral",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.2,
      1.0
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.45,
     "dust": 0.4
    },
    "transition": "cut"
   },
   {
    "offset": 65,
    "duration": 73,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 250,
      "y": 1560,
      "scale": 1.2,
      "expression": "resolve",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1590,
      "scale": 1.1,
      "expression": "resolve",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 820,
      "y": 1540,
      "scale": 1.15,
      "expression": "resolve",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "dust": 0.4
    },
    "transition": "fade"
   }
  ]
 },
 {
  "id": "scene-28",
  "segment": 28,
  "startFrame": 2772,
  "durationInFrames": 55,
  "holdFrames": 12,
  "visualDuration": 67,
  "lead": 0,
  "fadeOut": 0,
  "text": "Tapi keadaan berubah dengan cepat.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 300,
    "y": 1560,
    "scale": 1.2,
    "expression": "shock",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 760,
    "y": 1590,
    "scale": 1.1,
    "expression": "fear",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.55,
   "dust": 1.0,
   "tint": "rgba(150,60,30,0.18)",
   "shakePulses": [
    10,
    30
   ],
   "pulseAmp": 10
  },
  "voiceOver": "/audio/voiceover/segments/28.wav",
  "subtitles": [
   {
    "word": "Tapi",
    "start": 92.412,
    "end": 92.694
   },
   {
    "word": "keadaan",
    "start": 92.694,
    "end": 93.117
   },
   {
    "word": "berubah",
    "start": 93.117,
    "end": 93.54
   },
   {
    "word": "dengan",
    "start": 93.54,
    "end": 93.916
   },
   {
    "word": "cepat.",
    "start": 93.916,
    "end": 94.245
   }
  ],
  "sfx": [
   {
    "name": "explosion",
    "at": 10,
    "volume": 0.3
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 67,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 300,
      "y": 1560,
      "scale": 1.2,
      "expression": "shock",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 760,
      "y": 1590,
      "scale": 1.1,
      "expression": "fear",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.05,
      1.2
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.55,
     "dust": 1.0,
     "tint": "rgba(150,60,30,0.18)",
     "shakePulses": [
      10,
      30
     ],
     "pulseAmp": 10
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-29",
  "segment": 29,
  "startFrame": 2839,
  "durationInFrames": 62,
  "holdFrames": 9,
  "visualDuration": 71,
  "lead": 0,
  "fadeOut": 0,
  "text": "Tank mereka mengalami kerusakan.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank.png",
    "x": 540,
    "y": 1480,
    "scale": 1.2,
    "expression": "neutral",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.6,
   "smoke": 1.0,
   "flash": [
    4
   ],
   "impact": [
    4
   ],
   "impactAt": [
    50,
    70
   ],
   "shakePulses": [
    4
   ],
   "pulseAmp": 26
  },
  "voiceOver": "/audio/voiceover/segments/29.wav",
  "subtitles": [
   {
    "word": "Tank",
    "start": 94.649,
    "end": 94.995
   },
   {
    "word": "mereka",
    "start": 94.995,
    "end": 95.455
   },
   {
    "word": "mengalami",
    "start": 95.455,
    "end": 96.089
   },
   {
    "word": "kerusakan.",
    "start": 96.089,
    "end": 96.722
   }
  ],
  "sfx": [
   {
    "name": "explosion",
    "at": 4,
    "volume": 0.55
   },
   {
    "name": "metal-impact",
    "at": 4,
    "volume": 0.5
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 71,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank.png",
      "x": 540,
      "y": 1480,
      "scale": 1.2,
      "expression": "neutral",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.6,
     "smoke": 1.0,
     "flash": [
      4
     ],
     "impact": [
      4
     ],
     "impactAt": [
      50,
      70
     ],
     "shakePulses": [
      4
     ],
     "pulseAmp": 26
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-30",
  "segment": 30,
  "startFrame": 2910,
  "durationInFrames": 54,
  "holdFrames": 5,
  "visualDuration": 59,
  "lead": 0,
  "fadeOut": 0,
  "text": "Mereka kehilangan bantuan.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 260,
    "y": 1580,
    "scale": 1.1,
    "expression": "shock",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 640,
    "y": 1530,
    "scale": 1.15,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/tank-commander.png",
    "x": 900,
    "y": 1530,
    "scale": 1.1,
    "expression": "grim",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.55,
   "smoke": 0.7,
   "tint": "rgba(150,30,20,0.22)",
   "shakePulses": [
    20
   ],
   "pulseAmp": 8
  },
  "voiceOver": "/audio/voiceover/segments/30.wav",
  "subtitles": [
   {
    "word": "Mereka",
    "start": 96.99,
    "end": 97.483
   },
   {
    "word": "kehilangan",
    "start": 97.483,
    "end": 98.223
   },
   {
    "word": "bantuan.",
    "start": 98.223,
    "end": 98.778
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 59,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 260,
      "y": 1580,
      "scale": 1.1,
      "expression": "shock",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 640,
      "y": 1530,
      "scale": 1.15,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/tank-commander.png",
      "x": 900,
      "y": 1530,
      "scale": 1.1,
      "expression": "grim",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.55,
     "smoke": 0.7,
     "tint": "rgba(150,30,20,0.22)",
     "shakePulses": [
      20
     ],
     "pulseAmp": 8
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-31",
  "segment": 31,
  "startFrame": 2969,
  "durationInFrames": 55,
  "holdFrames": 12,
  "visualDuration": 67,
  "lead": 8,
  "fadeOut": 0,
  "text": "Dan tidak lama kemudian...",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 540,
    "y": 1540,
    "scale": 1.3,
    "expression": "grim",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.6,
   "dust": 0.6,
   "tint": "rgba(60,30,40,0.18)"
  },
  "voiceOver": "/audio/voiceover/segments/31.wav",
  "subtitles": [
   {
    "word": "Dan",
    "start": 98.967,
    "end": 99.296
   },
   {
    "word": "tidak",
    "start": 99.296,
    "end": 99.758
   },
   {
    "word": "lama",
    "start": 99.758,
    "end": 100.153
   },
   {
    "word": "kemudian...",
    "start": 100.153,
    "end": 100.812
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 67,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 540,
      "y": 1540,
      "scale": 1.3,
      "expression": "grim",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      45
     ]
    },
    "effects": {
     "vignette": 0.6,
     "dust": 0.6,
     "tint": "rgba(60,30,40,0.18)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-32",
  "segment": 32,
  "startFrame": 3036,
  "durationInFrames": 130,
  "holdFrames": 10,
  "visualDuration": 140,
  "lead": 0,
  "fadeOut": 0,
  "text": "dari kejauhan muncul sesuatu yang jauh lebih mengerikan.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 300,
    "y": 1580,
    "scale": 1.05,
    "expression": "shock",
    "pose": "stand"
   },
   {
    "asset": "/characters/tank-commander.png",
    "x": 620,
    "y": 1560,
    "scale": 1.15,
    "expression": "grim",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.55,
   "dust": 0.5
  },
  "voiceOver": "/audio/voiceover/segments/32.wav",
  "subtitles": [
   {
    "word": "dari",
    "start": 101.194,
    "end": 101.599
   },
   {
    "word": "kejauhan",
    "start": 101.599,
    "end": 102.275
   },
   {
    "word": "muncul",
    "start": 102.275,
    "end": 102.815
   },
   {
    "word": "sesuatu",
    "start": 102.815,
    "end": 103.423
   },
   {
    "word": "yang",
    "start": 103.423,
    "end": 103.828
   },
   {
    "word": "jauh",
    "start": 103.828,
    "end": 104.234
   },
   {
    "word": "lebih",
    "start": 104.234,
    "end": 104.706
   },
   {
    "word": "mengerikan.",
    "start": 104.706,
    "end": 105.517
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 60,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 300,
      "y": 1580,
      "scale": 1.05,
      "expression": "shock",
      "pose": "stand"
     },
     {
      "asset": "/characters/tank-commander.png",
      "x": 620,
      "y": 1560,
      "scale": 1.15,
      "expression": "grim",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.55,
     "dust": 0.5
    },
    "transition": "cut"
   },
   {
    "offset": 60,
    "duration": 80,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/enemy-troops.png",
      "x": 700,
      "y": 1180,
      "scale": 0.4,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 540,
      "y": 1190,
      "scale": 0.35,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 8
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 880,
      "y": 1190,
      "scale": 0.38,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 16
     }
    ],
    "camera": {
     "zoom": [
      1.1,
      1.4
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      55,
      62
     ]
    },
    "effects": {
     "vignette": 0.6,
     "dust": 0.8
    },
    "transition": "fade"
   }
  ]
 },
 {
  "id": "scene-33",
  "segment": 33,
  "startFrame": 3176,
  "durationInFrames": 165,
  "holdFrames": 13,
  "visualDuration": 178,
  "lead": 0,
  "fadeOut": 0,
  "text": "Pasukan SS dalam jumlah besar sedang bergerak menuju posisi mereka.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/enemy-troops.png",
    "x": 540,
    "y": 1210,
    "scale": 0.5,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 300,
    "y": 1260,
    "scale": 0.8,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade",
    "delay": 15
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 800,
    "y": 1290,
    "scale": 0.9,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade",
    "delay": 30
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 540,
    "y": 1430,
    "scale": 1.4,
    "expression": "neutral",
    "pose": "stand",
    "enter": "rise",
    "delay": 50
   }
  ],
  "effects": {
   "vignette": 0.5,
   "dust": 0.5
  },
  "voiceOver": "/audio/voiceover/segments/33.wav",
  "subtitles": [
   {
    "word": "Pasukan",
    "start": 105.883,
    "end": 106.526
   },
   {
    "word": "SS",
    "start": 106.526,
    "end": 106.812
   },
   {
    "word": "dalam",
    "start": 106.812,
    "end": 107.312
   },
   {
    "word": "jumlah",
    "start": 107.312,
    "end": 107.884
   },
   {
    "word": "besar",
    "start": 107.884,
    "end": 108.384
   },
   {
    "word": "sedang",
    "start": 108.384,
    "end": 108.956
   },
   {
    "word": "bergerak",
    "start": 108.956,
    "end": 109.671
   },
   {
    "word": "menuju",
    "start": 109.671,
    "end": 110.243
   },
   {
    "word": "posisi",
    "start": 110.243,
    "end": 110.814
   },
   {
    "word": "mereka.",
    "start": 110.814,
    "end": 111.386
   }
  ],
  "sfx": [
   {
    "name": "footsteps",
    "at": 30,
    "volume": 0.3
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 178,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/enemy-troops.png",
      "x": 540,
      "y": 1210,
      "scale": 0.5,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 300,
      "y": 1260,
      "scale": 0.8,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 15
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 800,
      "y": 1290,
      "scale": 0.9,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 30
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 540,
      "y": 1430,
      "scale": 1.4,
      "expression": "neutral",
      "pose": "stand",
      "enter": "rise",
      "delay": 50
     }
    ],
    "camera": {
     "zoom": [
      1.35,
      1.0
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "dust": 0.5
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-34",
  "segment": 34,
  "startFrame": 3354,
  "durationInFrames": 32,
  "holdFrames": 12,
  "visualDuration": 44,
  "lead": 0,
  "fadeOut": 0,
  "text": "Bukan puluhan orang.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/enemy-troops.png",
    "x": 540,
    "y": 1250,
    "scale": 0.9,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 250,
    "y": 1300,
    "scale": 0.8,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 830,
    "y": 1300,
    "scale": 0.8,
    "expression": "neutral",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.55,
   "dust": 0.5
  },
  "voiceOver": "/audio/voiceover/segments/34.wav",
  "subtitles": [
   {
    "word": "Bukan",
    "start": 111.801,
    "end": 112.131
   },
   {
    "word": "puluhan",
    "start": 112.131,
    "end": 112.554
   },
   {
    "word": "orang.",
    "start": 112.554,
    "end": 112.884
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 44,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/enemy-troops.png",
      "x": 540,
      "y": 1250,
      "scale": 0.9,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 250,
      "y": 1300,
      "scale": 0.8,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 830,
      "y": 1300,
      "scale": 0.8,
      "expression": "neutral",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.55,
     "dust": 0.5
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-35",
  "segment": 35,
  "startFrame": 3398,
  "durationInFrames": 53,
  "holdFrames": 10,
  "visualDuration": 63,
  "lead": 0,
  "fadeOut": 0,
  "text": "Tapi ratusan tentara.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/enemy-troops.png",
    "x": 200,
    "y": 1200,
    "scale": 0.6,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 540,
    "y": 1190,
    "scale": 0.65,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade",
    "delay": 4
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 880,
    "y": 1200,
    "scale": 0.6,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade",
    "delay": 8
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 380,
    "y": 1310,
    "scale": 0.9,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade",
    "delay": 12
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 700,
    "y": 1310,
    "scale": 0.9,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade",
    "delay": 16
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 540,
    "y": 1460,
    "scale": 1.3,
    "expression": "neutral",
    "pose": "stand",
    "enter": "rise",
    "delay": 20
   }
  ],
  "effects": {
   "vignette": 0.5,
   "dust": 0.6
  },
  "voiceOver": "/audio/voiceover/segments/35.wav",
  "subtitles": [
   {
    "word": "Tapi",
    "start": 113.272,
    "end": 113.715
   },
   {
    "word": "ratusan",
    "start": 113.715,
    "end": 114.38
   },
   {
    "word": "tentara.",
    "start": 114.38,
    "end": 115.045
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 63,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/enemy-troops.png",
      "x": 200,
      "y": 1200,
      "scale": 0.6,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 540,
      "y": 1190,
      "scale": 0.65,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 4
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 880,
      "y": 1200,
      "scale": 0.6,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 8
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 380,
      "y": 1310,
      "scale": 0.9,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 12
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 700,
      "y": 1310,
      "scale": 0.9,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 16
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 540,
      "y": 1460,
      "scale": 1.3,
      "expression": "neutral",
      "pose": "stand",
      "enter": "rise",
      "delay": 20
     }
    ],
    "camera": {
     "zoom": [
      1.5,
      0.92
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "dust": 0.6
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-36",
  "segment": 36,
  "startFrame": 3461,
  "durationInFrames": 62,
  "holdFrames": 11,
  "visualDuration": 73,
  "lead": 0,
  "fadeOut": 0,
  "text": "Sekarang mereka punya dua pilihan.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 280,
    "y": 1550,
    "scale": 1.1,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1580,
    "scale": 1.0,
    "expression": "fear",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 800,
    "y": 1530,
    "scale": 1.1,
    "expression": "grim",
    "pose": "stand",
    "flip": true
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 540,
    "y": 1170,
    "scale": 0.4,
    "expression": "neutral",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.55,
   "dust": 0.4
  },
  "voiceOver": "/audio/voiceover/segments/36.wav",
  "subtitles": [
   {
    "word": "Sekarang",
    "start": 115.376,
    "end": 115.906
   },
   {
    "word": "mereka",
    "start": 115.906,
    "end": 116.33
   },
   {
    "word": "punya",
    "start": 116.33,
    "end": 116.701
   },
   {
    "word": "dua",
    "start": 116.701,
    "end": 116.966
   },
   {
    "word": "pilihan.",
    "start": 116.966,
    "end": 117.443
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 73,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 280,
      "y": 1550,
      "scale": 1.1,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1580,
      "scale": 1.0,
      "expression": "fear",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 800,
      "y": 1530,
      "scale": 1.1,
      "expression": "grim",
      "pose": "stand",
      "flip": true
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 540,
      "y": 1170,
      "scale": 0.4,
      "expression": "neutral",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.08
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.55,
     "dust": 0.4
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-37",
  "segment": 37,
  "startFrame": 3534,
  "durationInFrames": 43,
  "holdFrames": 9,
  "visualDuration": 52,
  "lead": 0,
  "fadeOut": 0,
  "text": "Meninggalkan posisi itu...",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 400,
    "y": 1540,
    "scale": 1.2,
    "expression": "tired",
    "pose": "stand",
    "flip": true
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 700,
    "y": 1580,
    "scale": 1.05,
    "expression": "fear",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.5,
   "dust": 0.3
  },
  "voiceOver": "/audio/voiceover/segments/37.wav",
  "subtitles": [
   {
    "word": "Meninggalkan",
    "start": 117.797,
    "end": 118.538
   },
   {
    "word": "posisi",
    "start": 118.538,
    "end": 118.961
   },
   {
    "word": "itu...",
    "start": 118.961,
    "end": 119.226
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 52,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 400,
      "y": 1540,
      "scale": 1.2,
      "expression": "tired",
      "pose": "stand",
      "flip": true
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 700,
      "y": 1580,
      "scale": 1.05,
      "expression": "fear",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.08
     ],
     "panX": [
      0,
      60
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "dust": 0.3
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-38",
  "segment": 38,
  "startFrame": 3586,
  "durationInFrames": 73,
  "holdFrames": 14,
  "visualDuration": 87,
  "lead": 0,
  "fadeOut": 0,
  "text": "atau tetap bertahan dan menghadapi mereka.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 250,
    "y": 1540,
    "scale": 1.2,
    "expression": "resolve",
    "pose": "aim"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 520,
    "y": 1580,
    "scale": 1.05,
    "expression": "resolve",
    "pose": "aim"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 790,
    "y": 1520,
    "scale": 1.15,
    "expression": "resolve",
    "pose": "aim"
   }
  ],
  "effects": {
   "vignette": 0.5,
   "dust": 0.4
  },
  "voiceOver": "/audio/voiceover/segments/38.wav",
  "subtitles": [
   {
    "word": "atau",
    "start": 119.544,
    "end": 119.85
   },
   {
    "word": "tetap",
    "start": 119.85,
    "end": 120.207
   },
   {
    "word": "bertahan",
    "start": 120.207,
    "end": 120.717
   },
   {
    "word": "dan",
    "start": 120.717,
    "end": 120.973
   },
   {
    "word": "menghadapi",
    "start": 120.973,
    "end": 121.585
   },
   {
    "word": "mereka.",
    "start": 121.585,
    "end": 121.993
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 87,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 250,
      "y": 1540,
      "scale": 1.2,
      "expression": "resolve",
      "pose": "aim"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 520,
      "y": 1580,
      "scale": 1.05,
      "expression": "resolve",
      "pose": "aim"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 790,
      "y": 1520,
      "scale": 1.15,
      "expression": "resolve",
      "pose": "aim"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.12
     ],
     "panX": [
      0,
      -40
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "dust": 0.4
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-39",
  "segment": 39,
  "startFrame": 3673,
  "durationInFrames": 108,
  "holdFrames": 9,
  "visualDuration": 117,
  "lead": 0,
  "fadeOut": 0,
  "text": "Mereka tahu persis apa yang mungkin terjadi.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 540,
    "y": 1540,
    "scale": 1.4,
    "expression": "grim",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.65,
   "tint": "rgba(8,10,22,0.38)"
  },
  "voiceOver": "/audio/voiceover/segments/39.wav",
  "subtitles": [
   {
    "word": "Mereka",
    "start": 122.424,
    "end": 122.991
   },
   {
    "word": "tahu",
    "start": 122.991,
    "end": 123.416
   },
   {
    "word": "persis",
    "start": 123.416,
    "end": 123.983
   },
   {
    "word": "apa",
    "start": 123.983,
    "end": 124.337
   },
   {
    "word": "yang",
    "start": 124.337,
    "end": 124.762
   },
   {
    "word": "mungkin",
    "start": 124.762,
    "end": 125.4
   },
   {
    "word": "terjadi.",
    "start": 125.4,
    "end": 126.038
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 117,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 540,
      "y": 1540,
      "scale": 1.4,
      "expression": "grim",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.2
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.65,
     "tint": "rgba(8,10,22,0.38)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-40",
  "segment": 40,
  "startFrame": 3790,
  "durationInFrames": 97,
  "holdFrames": 11,
  "visualDuration": 108,
  "lead": 0,
  "fadeOut": 0,
  "text": "Mereka tahu jumlah mereka terlalu sedikit.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 180,
    "y": 1560,
    "scale": 0.8,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 330,
    "y": 1580,
    "scale": 0.7,
    "expression": "fear",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 470,
    "y": 1540,
    "scale": 0.8,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 600,
    "y": 1540,
    "scale": 0.75,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 820,
    "y": 1300,
    "scale": 1.2,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 900,
    "y": 1180,
    "scale": 0.8,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade",
    "delay": 10
   }
  ],
  "effects": {
   "vignette": 0.55,
   "dust": 0.5
  },
  "voiceOver": "/audio/voiceover/segments/40.wav",
  "subtitles": [
   {
    "word": "Mereka",
    "start": 126.347,
    "end": 126.887
   },
   {
    "word": "tahu",
    "start": 126.887,
    "end": 127.293
   },
   {
    "word": "jumlah",
    "start": 127.293,
    "end": 127.833
   },
   {
    "word": "mereka",
    "start": 127.833,
    "end": 128.374
   },
   {
    "word": "terlalu",
    "start": 128.374,
    "end": 128.982
   },
   {
    "word": "sedikit.",
    "start": 128.982,
    "end": 129.59
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 108,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 180,
      "y": 1560,
      "scale": 0.8,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 330,
      "y": 1580,
      "scale": 0.7,
      "expression": "fear",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 470,
      "y": 1540,
      "scale": 0.8,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 600,
      "y": 1540,
      "scale": 0.75,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 820,
      "y": 1300,
      "scale": 1.2,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 900,
      "y": 1180,
      "scale": 0.8,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 10
     }
    ],
    "camera": {
     "zoom": [
      1.1,
      1.0
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.55,
     "dust": 0.5
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-41",
  "segment": 41,
  "startFrame": 3898,
  "durationInFrames": 68,
  "holdFrames": 12,
  "visualDuration": 80,
  "lead": 0,
  "fadeOut": 0,
  "text": "Mereka tahu tank mereka sudah rusak.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank.png",
    "x": 540,
    "y": 1440,
    "scale": 1.3,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/tank-commander.png",
    "x": 250,
    "y": 1570,
    "scale": 0.9,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 850,
    "y": 1590,
    "scale": 0.9,
    "expression": "fear",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.6,
   "smoke": 0.9,
   "shakePulses": [
    20
   ],
   "pulseAmp": 6
  },
  "voiceOver": "/audio/voiceover/segments/41.wav",
  "subtitles": [
   {
    "word": "Mereka",
    "start": 129.941,
    "end": 130.375
   },
   {
    "word": "tahu",
    "start": 130.375,
    "end": 130.701
   },
   {
    "word": "tank",
    "start": 130.701,
    "end": 131.027
   },
   {
    "word": "mereka",
    "start": 131.027,
    "end": 131.462
   },
   {
    "word": "sudah",
    "start": 131.462,
    "end": 131.842
   },
   {
    "word": "rusak.",
    "start": 131.842,
    "end": 132.222
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 80,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank.png",
      "x": 540,
      "y": 1440,
      "scale": 1.3,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/tank-commander.png",
      "x": 250,
      "y": 1570,
      "scale": 0.9,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 850,
      "y": 1590,
      "scale": 0.9,
      "expression": "fear",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.6,
     "smoke": 0.9,
     "shakePulses": [
      20
     ],
     "pulseAmp": 6
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-42",
  "segment": 42,
  "startFrame": 3978,
  "durationInFrames": 86,
  "holdFrames": 9,
  "visualDuration": 95,
  "lead": 0,
  "fadeOut": 0,
  "text": "Tapi mereka tetap memilih bertahan.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 270,
    "y": 1540,
    "scale": 1.25,
    "expression": "resolve",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1570,
    "scale": 1.15,
    "expression": "resolve",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 810,
    "y": 1520,
    "scale": 1.2,
    "expression": "resolve",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.55,
   "dust": 0.3
  },
  "voiceOver": "/audio/voiceover/segments/42.wav",
  "subtitles": [
   {
    "word": "Tapi",
    "start": 132.6,
    "end": 133.031
   },
   {
    "word": "mereka",
    "start": 133.031,
    "end": 133.606
   },
   {
    "word": "tetap",
    "start": 133.606,
    "end": 134.108
   },
   {
    "word": "memilih",
    "start": 134.108,
    "end": 134.755
   },
   {
    "word": "bertahan.",
    "start": 134.755,
    "end": 135.473
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 95,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 270,
      "y": 1540,
      "scale": 1.25,
      "expression": "resolve",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1570,
      "scale": 1.15,
      "expression": "resolve",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 810,
      "y": 1520,
      "scale": 1.2,
      "expression": "resolve",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.2
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.55,
     "dust": 0.3
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-43",
  "segment": 43,
  "startFrame": 4073,
  "durationInFrames": 152,
  "holdFrames": 9,
  "visualDuration": 161,
  "lead": 0,
  "fadeOut": 0,
  "text": "Tank itu kemudian disamarkan seolah-olah sudah tidak bisa digunakan.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank.png",
    "x": 540,
    "y": 1470,
    "scale": 1.25,
    "expression": "neutral",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.6,
   "smoke": 0.5,
   "tint": "rgba(30,30,25,0.35)"
  },
  "voiceOver": "/audio/voiceover/segments/43.wav",
  "subtitles": [
   {
    "word": "Tank",
    "start": 135.754,
    "end": 136.154
   },
   {
    "word": "itu",
    "start": 136.154,
    "end": 136.488
   },
   {
    "word": "kemudian",
    "start": 136.488,
    "end": 137.155
   },
   {
    "word": "disamarkan",
    "start": 137.155,
    "end": 137.955
   },
   {
    "word": "seolah-olah",
    "start": 137.955,
    "end": 138.755
   },
   {
    "word": "sudah",
    "start": 138.755,
    "end": 139.222
   },
   {
    "word": "tidak",
    "start": 139.222,
    "end": 139.689
   },
   {
    "word": "bisa",
    "start": 139.689,
    "end": 140.089
   },
   {
    "word": "digunakan.",
    "start": 140.089,
    "end": 140.823
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 76,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank.png",
      "x": 540,
      "y": 1470,
      "scale": 1.25,
      "expression": "neutral",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.6,
     "smoke": 0.5,
     "tint": "rgba(30,30,25,0.35)"
    },
    "transition": "cut"
   },
   {
    "offset": 76,
    "duration": 85,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank.png",
      "x": 540,
      "y": 1470,
      "scale": 1.0,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 700,
      "y": 1190,
      "scale": 0.5,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade"
     }
    ],
    "camera": {
     "zoom": [
      1.15,
      1.3
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      60
     ]
    },
    "effects": {
     "vignette": 0.6,
     "dust": 0.5,
     "tint": "rgba(30,30,25,0.3)"
    },
    "transition": "fade"
   }
  ]
 },
 {
  "id": "scene-44",
  "segment": 44,
  "startFrame": 4234,
  "durationInFrames": 67,
  "holdFrames": 11,
  "visualDuration": 78,
  "lead": 0,
  "fadeOut": 0,
  "text": "Dan ketika pasukan musuh semakin dekat...",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank.png",
    "x": 300,
    "y": 1470,
    "scale": 1.0,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 700,
    "y": 1240,
    "scale": 0.9,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 880,
    "y": 1300,
    "scale": 1.1,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade",
    "delay": 10
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 540,
    "y": 1190,
    "scale": 0.6,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade"
   }
  ],
  "effects": {
   "vignette": 0.6,
   "dust": 0.5,
   "tint": "rgba(30,30,25,0.25)"
  },
  "voiceOver": "/audio/voiceover/segments/44.wav",
  "subtitles": [
   {
    "word": "Dan",
    "start": 141.145,
    "end": 141.393
   },
   {
    "word": "ketika",
    "start": 141.393,
    "end": 141.79
   },
   {
    "word": "pasukan",
    "start": 141.79,
    "end": 142.237
   },
   {
    "word": "musuh",
    "start": 142.237,
    "end": 142.584
   },
   {
    "word": "semakin",
    "start": 142.584,
    "end": 143.031
   },
   {
    "word": "dekat...",
    "start": 143.031,
    "end": 143.378
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 78,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank.png",
      "x": 300,
      "y": 1470,
      "scale": 1.0,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 700,
      "y": 1240,
      "scale": 0.9,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 880,
      "y": 1300,
      "scale": 1.1,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 10
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 540,
      "y": 1190,
      "scale": 0.6,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.2
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.6,
     "dust": 0.5,
     "tint": "rgba(30,30,25,0.25)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-45",
  "segment": 45,
  "startFrame": 4312,
  "durationInFrames": 55,
  "holdFrames": 12,
  "visualDuration": 67,
  "lead": 0,
  "fadeOut": 0,
  "text": "mereka membuka serangan.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/tank.png",
    "x": 300,
    "y": 1470,
    "scale": 1.3,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 850,
    "y": 1300,
    "scale": 1.0,
    "expression": "neutral",
    "pose": "stand",
    "exit": "fall",
    "exitAt": 12,
    "exitDur": 16
   }
  ],
  "effects": {
   "vignette": 0.5,
   "smoke": 0.8,
   "muzzle": [
    4
   ],
   "muzzleAt": [
    66,
    60
   ],
   "flash": [
    4
   ],
   "impact": [
    10,
    24
   ],
   "impactAt": [
    78,
    66
   ],
   "shakePulses": [
    4,
    14
   ],
   "pulseAmp": 24
  },
  "voiceOver": "/audio/voiceover/segments/45.wav",
  "subtitles": [
   {
    "word": "mereka",
    "start": 143.745,
    "end": 144.288
   },
   {
    "word": "membuka",
    "start": 144.288,
    "end": 144.899
   },
   {
    "word": "serangan.",
    "start": 144.899,
    "end": 145.578
   }
  ],
  "sfx": [
   {
    "name": "cannon",
    "at": 4,
    "volume": 0.55
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 67,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/tank.png",
      "x": 300,
      "y": 1470,
      "scale": 1.3,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 850,
      "y": 1300,
      "scale": 1.0,
      "expression": "neutral",
      "pose": "stand",
      "exit": "fall",
      "exitAt": 12,
      "exitDur": 16
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "smoke": 0.8,
     "muzzle": [
      4
     ],
     "muzzleAt": [
      66,
      60
     ],
     "flash": [
      4
     ],
     "impact": [
      10,
      24
     ],
     "impactAt": [
      78,
      66
     ],
     "shakePulses": [
      4,
      14
     ],
     "pulseAmp": 24
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-46",
  "segment": 46,
  "startFrame": 4379,
  "durationInFrames": 47,
  "holdFrames": 10,
  "visualDuration": 57,
  "lead": 0,
  "fadeOut": 0,
  "text": "Pertempuran pun dimulai.",
  "background": "/backgrounds/battlefield.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 220,
    "y": 1540,
    "scale": 1.2,
    "expression": "resolve",
    "pose": "aim"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 500,
    "y": 1560,
    "scale": 1.1,
    "expression": "resolve",
    "pose": "aim"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 800,
    "y": 1330,
    "scale": 1.2,
    "expression": "neutral",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.5,
   "smoke": 0.6,
   "muzzle": [
    4,
    14,
    26,
    38
   ],
   "muzzleAt": [
    36,
    63
   ],
   "shakePulses": [
    4,
    14,
    26,
    38
   ],
   "pulseAmp": 8
  },
  "voiceOver": "/audio/voiceover/segments/46.wav",
  "subtitles": [
   {
    "word": "Pertempuran",
    "start": 145.98,
    "end": 146.738
   },
   {
    "word": "pun",
    "start": 146.738,
    "end": 147.029
   },
   {
    "word": "dimulai.",
    "start": 147.029,
    "end": 147.554
   }
  ],
  "sfx": [
   {
    "name": "gunfire",
    "at": 4,
    "volume": 0.45
   },
   {
    "name": "gunfire",
    "at": 14,
    "volume": 0.45
   },
   {
    "name": "gunfire",
    "at": 26,
    "volume": 0.45
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 57,
    "background": "/backgrounds/battlefield.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 220,
      "y": 1540,
      "scale": 1.2,
      "expression": "resolve",
      "pose": "aim"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 500,
      "y": 1560,
      "scale": 1.1,
      "expression": "resolve",
      "pose": "aim"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 800,
      "y": 1330,
      "scale": 1.2,
      "expression": "neutral",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.08
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "smoke": 0.6,
     "muzzle": [
      4,
      14,
      26,
      38
     ],
     "muzzleAt": [
      36,
      63
     ],
     "shakePulses": [
      4,
      14,
      26,
      38
     ],
     "pulseAmp": 8
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-47",
  "segment": 47,
  "startFrame": 4436,
  "durationInFrames": 80,
  "holdFrames": 13,
  "visualDuration": 93,
  "lead": 0,
  "fadeOut": 0,
  "text": "Satu per satu musuh jatuh.",
  "background": "/backgrounds/battlefield.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 250,
    "y": 1540,
    "scale": 1.15,
    "expression": "resolve",
    "pose": "aim"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 650,
    "y": 1260,
    "scale": 0.7,
    "expression": "neutral",
    "pose": "stand",
    "exit": "fall",
    "exitAt": 15
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 820,
    "y": 1330,
    "scale": 0.9,
    "expression": "neutral",
    "pose": "stand",
    "exit": "fall",
    "exitAt": 35
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 960,
    "y": 1300,
    "scale": 0.8,
    "expression": "neutral",
    "pose": "stand",
    "exit": "fall",
    "exitAt": 55
   }
  ],
  "effects": {
   "vignette": 0.5,
   "dust": 0.4,
   "muzzle": [
    4,
    20,
    36,
    52,
    68
   ],
   "muzzleAt": [
    46,
    64
   ],
   "shakePulses": [
    4,
    20,
    36,
    52,
    68
   ],
   "pulseAmp": 7
  },
  "voiceOver": "/audio/voiceover/segments/47.wav",
  "subtitles": [
   {
    "word": "Satu",
    "start": 147.865,
    "end": 148.383
   },
   {
    "word": "per",
    "start": 148.383,
    "end": 148.814
   },
   {
    "word": "satu",
    "start": 148.814,
    "end": 149.331
   },
   {
    "word": "musuh",
    "start": 149.331,
    "end": 149.935
   },
   {
    "word": "jatuh.",
    "start": 149.935,
    "end": 150.539
   }
  ],
  "sfx": [
   {
    "name": "gunfire",
    "at": 4,
    "volume": 0.4
   },
   {
    "name": "gunfire",
    "at": 36,
    "volume": 0.4
   },
   {
    "name": "bullet-impact",
    "at": 20,
    "volume": 0.3
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 93,
    "background": "/backgrounds/battlefield.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 250,
      "y": 1540,
      "scale": 1.15,
      "expression": "resolve",
      "pose": "aim"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 650,
      "y": 1260,
      "scale": 0.7,
      "expression": "neutral",
      "pose": "stand",
      "exit": "fall",
      "exitAt": 15
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 820,
      "y": 1330,
      "scale": 0.9,
      "expression": "neutral",
      "pose": "stand",
      "exit": "fall",
      "exitAt": 35
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 960,
      "y": 1300,
      "scale": 0.8,
      "expression": "neutral",
      "pose": "stand",
      "exit": "fall",
      "exitAt": 55
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.08
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.5,
     "dust": 0.4,
     "muzzle": [
      4,
      20,
      36,
      52,
      68
     ],
     "muzzleAt": [
      46,
      64
     ],
     "shakePulses": [
      4,
      20,
      36,
      52,
      68
     ],
     "pulseAmp": 7
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-48",
  "segment": 48,
  "startFrame": 4529,
  "durationInFrames": 74,
  "holdFrames": 9,
  "visualDuration": 83,
  "lead": 0,
  "fadeOut": 0,
  "text": "Tapi jumlah mereka tidak ada habisnya.",
  "background": "/backgrounds/battlefield.png",
  "characters": [
   {
    "asset": "/characters/enemy-troops.png",
    "x": 400,
    "y": 1220,
    "scale": 0.7,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 700,
    "y": 1260,
    "scale": 0.9,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade",
    "delay": 6
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 950,
    "y": 1230,
    "scale": 0.7,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade",
    "delay": 10
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 540,
    "y": 1430,
    "scale": 1.4,
    "expression": "neutral",
    "pose": "stand",
    "enter": "rise",
    "delay": 20
   }
  ],
  "effects": {
   "vignette": 0.6,
   "dust": 0.8
  },
  "voiceOver": "/audio/voiceover/segments/48.wav",
  "subtitles": [
   {
    "word": "Tapi",
    "start": 150.962,
    "end": 151.297
   },
   {
    "word": "jumlah",
    "start": 151.297,
    "end": 151.743
   },
   {
    "word": "mereka",
    "start": 151.743,
    "end": 152.19
   },
   {
    "word": "tidak",
    "start": 152.19,
    "end": 152.581
   },
   {
    "word": "ada",
    "start": 152.581,
    "end": 152.86
   },
   {
    "word": "habisnya.",
    "start": 152.86,
    "end": 153.418
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 83,
    "background": "/backgrounds/battlefield.png",
    "characters": [
     {
      "asset": "/characters/enemy-troops.png",
      "x": 400,
      "y": 1220,
      "scale": 0.7,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 700,
      "y": 1260,
      "scale": 0.9,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 6
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 950,
      "y": 1230,
      "scale": 0.7,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade",
      "delay": 10
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 540,
      "y": 1430,
      "scale": 1.4,
      "expression": "neutral",
      "pose": "stand",
      "enter": "rise",
      "delay": 20
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.2
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.6,
     "dust": 0.8
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-49",
  "segment": 49,
  "startFrame": 4612,
  "durationInFrames": 138,
  "holdFrames": 4,
  "visualDuration": 142,
  "lead": 0,
  "fadeOut": 0,
  "text": "Sementara amunisi di dalam tank semakin sedikit.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 300,
    "y": 1540,
    "scale": 1.2,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 760,
    "y": 1570,
    "scale": 1.1,
    "expression": "fear",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.55,
   "smoke": 0.4,
   "tint": "rgba(8,10,22,0.38)",
   "shakePulses": [
    30,
    60
   ],
   "pulseAmp": 8
  },
  "voiceOver": "/audio/voiceover/segments/49.wav",
  "subtitles": [
   {
    "word": "Sementara",
    "start": 153.74,
    "end": 154.662
   },
   {
    "word": "amunisi",
    "start": 154.662,
    "end": 155.416
   },
   {
    "word": "di",
    "start": 155.416,
    "end": 155.751
   },
   {
    "word": "dalam",
    "start": 155.751,
    "end": 156.338
   },
   {
    "word": "tank",
    "start": 156.338,
    "end": 156.841
   },
   {
    "word": "semakin",
    "start": 156.841,
    "end": 157.595
   },
   {
    "word": "sedikit.",
    "start": 157.595,
    "end": 158.349
   }
  ],
  "sfx": [
   {
    "name": "reload",
    "at": 20,
    "volume": 0.4
   },
   {
    "name": "metal-impact",
    "at": 40,
    "volume": 0.4
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 70,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 300,
      "y": 1540,
      "scale": 1.2,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 760,
      "y": 1570,
      "scale": 1.1,
      "expression": "fear",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.55,
     "smoke": 0.4,
     "tint": "rgba(8,10,22,0.38)",
     "shakePulses": [
      30,
      60
     ],
     "pulseAmp": 8
    },
    "transition": "cut"
   },
   {
    "offset": 70,
    "duration": 72,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1590,
      "scale": 1.6,
      "expression": "tired",
      "pose": "aim"
     }
    ],
    "camera": {
     "zoom": [
      1.2,
      1.4
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.65,
     "smoke": 0.4,
     "tint": "rgba(8,10,22,0.38)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-50",
  "segment": 50,
  "startFrame": 4754,
  "durationInFrames": 25,
  "holdFrames": 12,
  "visualDuration": 37,
  "lead": 0,
  "fadeOut": 0,
  "text": "Dan awak tank itu...",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/veteran-crew.png",
    "x": 160,
    "y": 1520,
    "scale": 1.0,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 400,
    "y": 1520,
    "scale": 1.0,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 640,
    "y": 1520,
    "scale": 1.0,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/tank-commander.png",
    "x": 830,
    "y": 1540,
    "scale": 1.0,
    "expression": "grim",
    "pose": "stand",
    "flip": true
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 990,
    "y": 1570,
    "scale": 0.85,
    "expression": "fear",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.6,
   "tint": "rgba(8,10,22,0.38)"
  },
  "voiceOver": "/audio/voiceover/segments/50.wav",
  "subtitles": [
   {
    "word": "Dan",
    "start": 158.478,
    "end": 158.668
   },
   {
    "word": "awak",
    "start": 158.668,
    "end": 158.896
   },
   {
    "word": "tank",
    "start": 158.896,
    "end": 159.124
   },
   {
    "word": "itu...",
    "start": 159.124,
    "end": 159.314
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 37,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/veteran-crew.png",
      "x": 160,
      "y": 1520,
      "scale": 1.0,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 400,
      "y": 1520,
      "scale": 1.0,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 640,
      "y": 1520,
      "scale": 1.0,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/tank-commander.png",
      "x": 830,
      "y": 1540,
      "scale": 1.0,
      "expression": "grim",
      "pose": "stand",
      "flip": true
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 990,
      "y": 1570,
      "scale": 0.85,
      "expression": "fear",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.05
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.6,
     "tint": "rgba(8,10,22,0.38)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-51",
  "segment": 51,
  "startFrame": 4791,
  "durationInFrames": 58,
  "holdFrames": 16,
  "visualDuration": 74,
  "lead": 0,
  "fadeOut": 0,
  "text": "mulai gugur satu demi satu.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/veteran-crew.png",
    "x": 160,
    "y": 1520,
    "scale": 1.0,
    "expression": "grim",
    "pose": "stand",
    "exit": "fall",
    "exitAt": 8
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 400,
    "y": 1520,
    "scale": 1.0,
    "expression": "shock",
    "pose": "stand",
    "exit": "fall",
    "exitAt": 26
   },
   {
    "asset": "/characters/veteran-crew.png",
    "x": 640,
    "y": 1520,
    "scale": 1.0,
    "expression": "grim",
    "pose": "stand",
    "exit": "fall",
    "exitAt": 44
   },
   {
    "asset": "/characters/tank-commander.png",
    "x": 830,
    "y": 1540,
    "scale": 1.0,
    "expression": "grim",
    "pose": "stand",
    "flip": true
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 990,
    "y": 1570,
    "scale": 0.85,
    "expression": "fear",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.6,
   "smoke": 0.7,
   "tint": "rgba(150,30,20,0.22)",
   "flash": [
    8,
    26,
    44
   ],
   "shakePulses": [
    8,
    26,
    44
   ],
   "pulseAmp": 16
  },
  "voiceOver": "/audio/voiceover/segments/51.wav",
  "subtitles": [
   {
    "word": "mulai",
    "start": 159.698,
    "end": 160.124
   },
   {
    "word": "gugur",
    "start": 160.124,
    "end": 160.549
   },
   {
    "word": "satu",
    "start": 160.549,
    "end": 160.914
   },
   {
    "word": "demi",
    "start": 160.914,
    "end": 161.279
   },
   {
    "word": "satu.",
    "start": 161.279,
    "end": 161.644
   }
  ],
  "sfx": [
   {
    "name": "metal-impact",
    "at": 8,
    "volume": 0.5
   },
   {
    "name": "metal-impact",
    "at": 26,
    "volume": 0.5
   },
   {
    "name": "metal-impact",
    "at": 44,
    "volume": 0.5
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 74,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/veteran-crew.png",
      "x": 160,
      "y": 1520,
      "scale": 1.0,
      "expression": "grim",
      "pose": "stand",
      "exit": "fall",
      "exitAt": 8
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 400,
      "y": 1520,
      "scale": 1.0,
      "expression": "shock",
      "pose": "stand",
      "exit": "fall",
      "exitAt": 26
     },
     {
      "asset": "/characters/veteran-crew.png",
      "x": 640,
      "y": 1520,
      "scale": 1.0,
      "expression": "grim",
      "pose": "stand",
      "exit": "fall",
      "exitAt": 44
     },
     {
      "asset": "/characters/tank-commander.png",
      "x": 830,
      "y": 1540,
      "scale": 1.0,
      "expression": "grim",
      "pose": "stand",
      "flip": true
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 990,
      "y": 1570,
      "scale": 0.85,
      "expression": "fear",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.08
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.6,
     "smoke": 0.7,
     "tint": "rgba(150,30,20,0.22)",
     "flash": [
      8,
      26,
      44
     ],
     "shakePulses": [
      8,
      26,
      44
     ],
     "pulseAmp": 16
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-52",
  "segment": 52,
  "startFrame": 4865,
  "durationInFrames": 32,
  "holdFrames": 11,
  "visualDuration": 43,
  "lead": 8,
  "fadeOut": 0,
  "text": "Pada akhirnya...",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 300,
    "y": 1540,
    "scale": 1.25,
    "expression": "tired",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 760,
    "y": 1570,
    "scale": 1.1,
    "expression": "sad",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.7,
   "smoke": 0.5,
   "tint": "rgba(8,10,22,0.38)"
  },
  "voiceOver": "/audio/voiceover/segments/52.wav",
  "subtitles": [
   {
    "word": "Pada",
    "start": 162.156,
    "end": 162.56
   },
   {
    "word": "akhirnya...",
    "start": 162.56,
    "end": 163.232
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 43,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 300,
      "y": 1540,
      "scale": 1.25,
      "expression": "tired",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 760,
      "y": 1570,
      "scale": 1.1,
      "expression": "sad",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.7,
     "smoke": 0.5,
     "tint": "rgba(8,10,22,0.38)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-53",
  "segment": 53,
  "startFrame": 4908,
  "durationInFrames": 137,
  "holdFrames": 6,
  "visualDuration": 143,
  "lead": 0,
  "fadeOut": 0,
  "text": "hanya komandan dan prajurit baru itu yang masih bertahan.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 300,
    "y": 1540,
    "scale": 1.3,
    "expression": "tired",
    "pose": "aim"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 770,
    "y": 1570,
    "scale": 1.15,
    "expression": "tired",
    "pose": "aim",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.65,
   "smoke": 0.6,
   "tint": "rgba(8,10,22,0.38)",
   "shakePulses": [
    30,
    70
   ],
   "pulseAmp": 9
  },
  "voiceOver": "/audio/voiceover/segments/53.wav",
  "subtitles": [
   {
    "word": "hanya",
    "start": 163.596,
    "end": 164.08
   },
   {
    "word": "komandan",
    "start": 164.08,
    "end": 164.771
   },
   {
    "word": "dan",
    "start": 164.771,
    "end": 165.117
   },
   {
    "word": "prajurit",
    "start": 165.117,
    "end": 165.808
   },
   {
    "word": "baru",
    "start": 165.808,
    "end": 166.223
   },
   {
    "word": "itu",
    "start": 166.223,
    "end": 166.568
   },
   {
    "word": "yang",
    "start": 166.568,
    "end": 166.983
   },
   {
    "word": "masih",
    "start": 166.983,
    "end": 167.467
   },
   {
    "word": "bertahan.",
    "start": 167.467,
    "end": 168.158
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 80,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 300,
      "y": 1540,
      "scale": 1.3,
      "expression": "tired",
      "pose": "aim"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 770,
      "y": 1570,
      "scale": 1.15,
      "expression": "tired",
      "pose": "aim",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.65,
     "smoke": 0.6,
     "tint": "rgba(8,10,22,0.38)",
     "shakePulses": [
      30,
      70
     ],
     "pulseAmp": 9
    },
    "transition": "cut"
   },
   {
    "offset": 80,
    "duration": 63,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 540,
      "y": 1580,
      "scale": 1.6,
      "expression": "tired",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.1,
      1.3
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.7,
     "smoke": 0.5,
     "tint": "rgba(8,10,22,0.38)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-54",
  "segment": 54,
  "startFrame": 5051,
  "durationInFrames": 51,
  "holdFrames": 8,
  "visualDuration": 59,
  "lead": 0,
  "fadeOut": 0,
  "text": "Tetapi bahkan mereka tahu...",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 300,
    "y": 1540,
    "scale": 1.3,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 780,
    "y": 1570,
    "scale": 1.15,
    "expression": "fear",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.65,
   "smoke": 0.5,
   "tint": "rgba(8,10,22,0.38)"
  },
  "voiceOver": "/audio/voiceover/segments/54.wav",
  "subtitles": [
   {
    "word": "Tetapi",
    "start": 168.371,
    "end": 168.824
   },
   {
    "word": "bahkan",
    "start": 168.824,
    "end": 169.277
   },
   {
    "word": "mereka",
    "start": 169.277,
    "end": 169.729
   },
   {
    "word": "tahu...",
    "start": 169.729,
    "end": 170.069
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 59,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 300,
      "y": 1540,
      "scale": 1.3,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 780,
      "y": 1570,
      "scale": 1.15,
      "expression": "fear",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.65,
     "smoke": 0.5,
     "tint": "rgba(8,10,22,0.38)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-55",
  "segment": 55,
  "startFrame": 5110,
  "durationInFrames": 72,
  "holdFrames": 15,
  "visualDuration": 87,
  "lead": 0,
  "fadeOut": 0,
  "text": "waktunya hampir habis.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 300,
    "y": 1540,
    "scale": 1.35,
    "expression": "grim",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 780,
    "y": 1570,
    "scale": 1.15,
    "expression": "fear",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.6,
   "smoke": 0.8,
   "tint": "rgba(150,30,20,0.22)",
   "flash": [
    20,
    50
   ],
   "shakePulses": [
    20,
    50
   ],
   "pulseAmp": 14
  },
  "voiceOver": "/audio/voiceover/segments/55.wav",
  "subtitles": [
   {
    "word": "waktunya",
    "start": 170.338,
    "end": 171.3
   },
   {
    "word": "hampir",
    "start": 171.3,
    "end": 172.07
   },
   {
    "word": "habis.",
    "start": 172.07,
    "end": 172.744
   }
  ],
  "sfx": [
   {
    "name": "explosion",
    "at": 20,
    "volume": 0.45
   },
   {
    "name": "explosion",
    "at": 50,
    "volume": 0.45
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 87,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 300,
      "y": 1540,
      "scale": 1.35,
      "expression": "grim",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 780,
      "y": 1570,
      "scale": 1.15,
      "expression": "fear",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.1,
      1.25
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.6,
     "smoke": 0.8,
     "tint": "rgba(150,30,20,0.22)",
     "flash": [
      20,
      50
     ],
     "shakePulses": [
      20,
      50
     ],
     "pulseAmp": 14
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-56",
  "segment": 56,
  "startFrame": 5197,
  "durationInFrames": 140,
  "holdFrames": 10,
  "visualDuration": 150,
  "lead": 0,
  "fadeOut": 0,
  "text": "Komandan ini kemudian menyuruh prajurit baru itu keluar dan menyelamatkan dirinya.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 300,
    "y": 1540,
    "scale": 1.4,
    "expression": "resolve",
    "pose": "stand"
   },
   {
    "asset": "/characters/new-soldier.png",
    "x": 780,
    "y": 1570,
    "scale": 1.15,
    "expression": "shock",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.55,
   "smoke": 0.5,
   "tint": "rgba(8,10,22,0.38)"
  },
  "voiceOver": "/audio/voiceover/segments/56.wav",
  "subtitles": [
   {
    "word": "Komandan",
    "start": 173.217,
    "end": 173.72
   },
   {
    "word": "ini",
    "start": 173.72,
    "end": 173.971
   },
   {
    "word": "kemudian",
    "start": 173.971,
    "end": 174.474
   },
   {
    "word": "menyuruh",
    "start": 174.474,
    "end": 174.977
   },
   {
    "word": "prajurit",
    "start": 174.977,
    "end": 175.48
   },
   {
    "word": "baru",
    "start": 175.48,
    "end": 175.782
   },
   {
    "word": "itu",
    "start": 175.782,
    "end": 176.033
   },
   {
    "word": "keluar",
    "start": 176.033,
    "end": 176.436
   },
   {
    "word": "dan",
    "start": 176.436,
    "end": 176.687
   },
   {
    "word": "menyelamatkan",
    "start": 176.687,
    "end": 177.441
   },
   {
    "word": "dirinya.",
    "start": 177.441,
    "end": 177.894
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 70,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 300,
      "y": 1540,
      "scale": 1.4,
      "expression": "resolve",
      "pose": "stand"
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 780,
      "y": 1570,
      "scale": 1.15,
      "expression": "shock",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      30
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.55,
     "smoke": 0.5,
     "tint": "rgba(8,10,22,0.38)"
    },
    "transition": "cut"
   },
   {
    "offset": 70,
    "duration": 80,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 700,
      "y": 1560,
      "scale": 1.5,
      "expression": "grim",
      "pose": "stand",
      "flip": true
     },
     {
      "asset": "/characters/new-soldier.png",
      "x": 300,
      "y": 1590,
      "scale": 1.1,
      "expression": "sad",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.2
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.6,
     "smoke": 0.5,
     "tint": "rgba(8,10,22,0.38)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-57",
  "segment": 57,
  "startFrame": 5347,
  "durationInFrames": 32,
  "holdFrames": 8,
  "visualDuration": 40,
  "lead": 0,
  "fadeOut": 0,
  "text": "Karena dia tahu...",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 540,
    "y": 1590,
    "scale": 1.7,
    "expression": "tired",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.7,
   "tint": "rgba(8,10,22,0.38)"
  },
  "voiceOver": "/audio/voiceover/segments/57.wav",
  "subtitles": [
   {
    "word": "Karena",
    "start": 178.235,
    "end": 178.677
   },
   {
    "word": "dia",
    "start": 178.677,
    "end": 178.953
   },
   {
    "word": "tahu...",
    "start": 178.953,
    "end": 179.285
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 40,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 540,
      "y": 1590,
      "scale": 1.7,
      "expression": "tired",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.2,
      1.35
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.7,
     "tint": "rgba(8,10,22,0.38)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-58",
  "segment": 58,
  "startFrame": 5387,
  "durationInFrames": 108,
  "holdFrames": 13,
  "visualDuration": 121,
  "lead": 0,
  "fadeOut": 0,
  "text": "setidaknya satu orang dari kru ini harus tetap hidup.",
  "background": "/backgrounds/tank-interior.png",
  "characters": [
   {
    "asset": "/characters/tank-commander.png",
    "x": 540,
    "y": 1590,
    "scale": 1.75,
    "expression": "resolve",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.7,
   "smoke": 0.4,
   "tint": "rgba(8,10,22,0.38)"
  },
  "voiceOver": "/audio/voiceover/segments/58.wav",
  "subtitles": [
   {
    "word": "setidaknya",
    "start": 179.56,
    "end": 180.258
   },
   {
    "word": "satu",
    "start": 180.258,
    "end": 180.607
   },
   {
    "word": "orang",
    "start": 180.607,
    "end": 181.014
   },
   {
    "word": "dari",
    "start": 181.014,
    "end": 181.364
   },
   {
    "word": "kru",
    "start": 181.364,
    "end": 181.654
   },
   {
    "word": "ini",
    "start": 181.654,
    "end": 181.945
   },
   {
    "word": "harus",
    "start": 181.945,
    "end": 182.353
   },
   {
    "word": "tetap",
    "start": 182.353,
    "end": 182.76
   },
   {
    "word": "hidup.",
    "start": 182.76,
    "end": 183.167
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 121,
    "background": "/backgrounds/tank-interior.png",
    "characters": [
     {
      "asset": "/characters/tank-commander.png",
      "x": 540,
      "y": 1590,
      "scale": 1.75,
      "expression": "resolve",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.3,
      1.45
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      35
     ]
    },
    "effects": {
     "vignette": 0.7,
     "smoke": 0.4,
     "tint": "rgba(8,10,22,0.38)"
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-59",
  "segment": 59,
  "startFrame": 5508,
  "durationInFrames": 64,
  "holdFrames": 11,
  "visualDuration": 75,
  "lead": 8,
  "fadeOut": 0,
  "text": "Prajurit itu akhirnya meninggalkan tank.",
  "background": "/backgrounds/crossroads.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 260,
    "y": 1580,
    "scale": 1.1,
    "expression": "fear",
    "pose": "crouch"
   },
   {
    "asset": "/characters/tank.png",
    "x": 700,
    "y": 1470,
    "scale": 1.2,
    "expression": "neutral",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.6,
   "smoke": 0.9,
   "dust": 0.7,
   "tint": "rgba(60,30,40,0.18)",
   "flash": [
    20
   ],
   "shakePulses": [
    20,
    45
   ],
   "pulseAmp": 8
  },
  "voiceOver": "/audio/voiceover/segments/59.wav",
  "subtitles": [
   {
    "word": "Prajurit",
    "start": 183.615,
    "end": 184.091
   },
   {
    "word": "itu",
    "start": 184.091,
    "end": 184.329
   },
   {
    "word": "akhirnya",
    "start": 184.329,
    "end": 184.805
   },
   {
    "word": "meninggalkan",
    "start": 184.805,
    "end": 185.471
   },
   {
    "word": "tank.",
    "start": 185.471,
    "end": 185.757
   }
  ],
  "sfx": [
   {
    "name": "footsteps",
    "at": 10,
    "volume": 0.35
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 75,
    "background": "/backgrounds/crossroads.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 260,
      "y": 1580,
      "scale": 1.1,
      "expression": "fear",
      "pose": "crouch"
     },
     {
      "asset": "/characters/tank.png",
      "x": 700,
      "y": 1470,
      "scale": 1.2,
      "expression": "neutral",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.6,
     "smoke": 0.9,
     "dust": 0.7,
     "tint": "rgba(60,30,40,0.18)",
     "flash": [
      20
     ],
     "shakePulses": [
      20,
      45
     ],
     "pulseAmp": 8
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-60",
  "segment": 60,
  "startFrame": 5583,
  "durationInFrames": 64,
  "holdFrames": 8,
  "visualDuration": 72,
  "lead": 0,
  "fadeOut": 0,
  "text": "Dia bersembunyi di bawah tank.",
  "background": "/backgrounds/under-tank.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1620,
    "scale": 1.3,
    "expression": "fear",
    "pose": "crouch"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 820,
    "y": 1300,
    "scale": 0.5,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 300,
    "y": 1320,
    "scale": 0.55,
    "expression": "neutral",
    "pose": "stand"
   }
  ],
  "effects": {
   "vignette": 0.7,
   "dust": 0.8
  },
  "voiceOver": "/audio/voiceover/segments/60.wav",
  "subtitles": [
   {
    "word": "Dia",
    "start": 186.108,
    "end": 186.411
   },
   {
    "word": "bersembunyi",
    "start": 186.411,
    "end": 187.199
   },
   {
    "word": "di",
    "start": 187.199,
    "end": 187.441
   },
   {
    "word": "bawah",
    "start": 187.441,
    "end": 187.865
   },
   {
    "word": "tank.",
    "start": 187.865,
    "end": 188.229
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 72,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1620,
      "scale": 1.3,
      "expression": "fear",
      "pose": "crouch"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 820,
      "y": 1300,
      "scale": 0.5,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 300,
      "y": 1320,
      "scale": 0.55,
      "expression": "neutral",
      "pose": "stand"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      -60
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.7,
     "dust": 0.8
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-61",
  "segment": 61,
  "startFrame": 5655,
  "durationInFrames": 91,
  "holdFrames": 14,
  "visualDuration": 105,
  "lead": 0,
  "fadeOut": 0,
  "text": "sementara pasukan musuh bergerak melewatinya.",
  "background": "/backgrounds/under-tank.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1650,
    "scale": 1.3,
    "expression": "fear",
    "pose": "crouch",
    "freeze": true
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 700,
    "y": 1300,
    "scale": 0.7,
    "expression": "neutral",
    "pose": "stand",
    "exit": "slide-left",
    "exitAt": 0,
    "exitDur": 90
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 950,
    "y": 1330,
    "scale": 0.8,
    "expression": "neutral",
    "pose": "stand",
    "exit": "slide-left",
    "exitAt": 20,
    "exitDur": 70
   }
  ],
  "effects": {
   "vignette": 0.75,
   "dust": 0.9
  },
  "voiceOver": "/audio/voiceover/segments/61.wav",
  "subtitles": [
   {
    "word": "sementara",
    "start": 188.486,
    "end": 189.15
   },
   {
    "word": "pasukan",
    "start": 189.15,
    "end": 189.694
   },
   {
    "word": "musuh",
    "start": 189.694,
    "end": 190.116
   },
   {
    "word": "bergerak",
    "start": 190.116,
    "end": 190.72
   },
   {
    "word": "melewatinya.",
    "start": 190.72,
    "end": 191.505
   }
  ],
  "sfx": [
   {
    "name": "footsteps",
    "at": 0,
    "volume": 0.4
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 105,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1650,
      "scale": 1.3,
      "expression": "fear",
      "pose": "crouch",
      "freeze": true
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 700,
      "y": 1300,
      "scale": 0.7,
      "expression": "neutral",
      "pose": "stand",
      "exit": "slide-left",
      "exitAt": 0,
      "exitDur": 90
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 950,
      "y": 1330,
      "scale": 0.8,
      "expression": "neutral",
      "pose": "stand",
      "exit": "slide-left",
      "exitAt": 20,
      "exitDur": 70
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.75,
     "dust": 0.9
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-62",
  "segment": 62,
  "startFrame": 5760,
  "durationInFrames": 86,
  "holdFrames": 10,
  "visualDuration": 96,
  "lead": 0,
  "fadeOut": 0,
  "text": "Kemudian seorang tentara Jerman menemukannya.",
  "background": "/backgrounds/under-tank.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 300,
    "y": 1700,
    "scale": 1.2,
    "expression": "fear",
    "pose": "crouch",
    "freeze": true
   },
   {
    "asset": "/characters/german-soldier.png",
    "x": 800,
    "y": 1260,
    "scale": 1.0,
    "expression": "neutral",
    "pose": "stand",
    "enter": "slide-left"
   }
  ],
  "effects": {
   "vignette": 0.8
  },
  "voiceOver": "/audio/voiceover/segments/62.wav",
  "subtitles": [
   {
    "word": "Kemudian",
    "start": 191.988,
    "end": 192.564
   },
   {
    "word": "seorang",
    "start": 192.564,
    "end": 193.082
   },
   {
    "word": "tentara",
    "start": 193.082,
    "end": 193.601
   },
   {
    "word": "Jerman",
    "start": 193.601,
    "end": 194.062
   },
   {
    "word": "menemukannya.",
    "start": 194.062,
    "end": 194.868
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 96,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 300,
      "y": 1700,
      "scale": 1.2,
      "expression": "fear",
      "pose": "crouch",
      "freeze": true
     },
     {
      "asset": "/characters/german-soldier.png",
      "x": 800,
      "y": 1260,
      "scale": 1.0,
      "expression": "neutral",
      "pose": "stand",
      "enter": "slide-left"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.25
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      70,
      60
     ]
    },
    "effects": {
     "vignette": 0.8
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-63",
  "segment": 63,
  "startFrame": 5856,
  "durationInFrames": 54,
  "holdFrames": 8,
  "visualDuration": 62,
  "lead": 0,
  "fadeOut": 0,
  "text": "Prajurit itu tidak bergerak.",
  "background": "/backgrounds/under-tank.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1660,
    "scale": 1.7,
    "expression": "fear",
    "pose": "crouch",
    "freeze": true
   }
  ],
  "effects": {
   "vignette": 0.85
  },
  "voiceOver": "/audio/voiceover/segments/63.wav",
  "subtitles": [
   {
    "word": "Prajurit",
    "start": 195.185,
    "end": 195.748
   },
   {
    "word": "itu",
    "start": 195.748,
    "end": 196.029
   },
   {
    "word": "tidak",
    "start": 196.029,
    "end": 196.423
   },
   {
    "word": "bergerak.",
    "start": 196.423,
    "end": 196.985
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 62,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1660,
      "scale": 1.7,
      "expression": "fear",
      "pose": "crouch",
      "freeze": true
     }
    ],
    "camera": {
     "zoom": [
      1.1,
      1.3
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.85
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-64",
  "segment": 64,
  "startFrame": 5918,
  "durationInFrames": 63,
  "holdFrames": 12,
  "visualDuration": 75,
  "lead": 0,
  "fadeOut": 0,
  "text": "Dia hanya diam dan menunggu.",
  "background": "/backgrounds/under-tank.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 300,
    "y": 1680,
    "scale": 1.2,
    "expression": "fear",
    "pose": "crouch",
    "freeze": true
   },
   {
    "asset": "/characters/german-soldier.png",
    "x": 780,
    "y": 1300,
    "scale": 1.15,
    "expression": "neutral",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.8
  },
  "voiceOver": "/audio/voiceover/segments/64.wav",
  "subtitles": [
   {
    "word": "Dia",
    "start": 197.273,
    "end": 197.594
   },
   {
    "word": "hanya",
    "start": 197.594,
    "end": 198.042
   },
   {
    "word": "diam",
    "start": 198.042,
    "end": 198.427
   },
   {
    "word": "dan",
    "start": 198.427,
    "end": 198.748
   },
   {
    "word": "menunggu.",
    "start": 198.748,
    "end": 199.389
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 75,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 300,
      "y": 1680,
      "scale": 1.2,
      "expression": "fear",
      "pose": "crouch",
      "freeze": true
     },
     {
      "asset": "/characters/german-soldier.png",
      "x": 780,
      "y": 1300,
      "scale": 1.15,
      "expression": "neutral",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.8
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-65",
  "segment": 65,
  "startFrame": 5993,
  "durationInFrames": 83,
  "holdFrames": 11,
  "visualDuration": 94,
  "lead": 0,
  "fadeOut": 0,
  "text": "Tentara Jerman itu bisa saja membunuhnya.",
  "background": "/backgrounds/under-tank.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 300,
    "y": 1690,
    "scale": 1.2,
    "expression": "fear",
    "pose": "crouch",
    "freeze": true
   },
   {
    "asset": "/characters/german-soldier.png",
    "x": 800,
    "y": 1300,
    "scale": 1.15,
    "expression": "neutral",
    "pose": "aim",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.85
  },
  "voiceOver": "/audio/voiceover/segments/65.wav",
  "subtitles": [
   {
    "word": "Tentara",
    "start": 199.782,
    "end": 200.311
   },
   {
    "word": "Jerman",
    "start": 200.311,
    "end": 200.782
   },
   {
    "word": "itu",
    "start": 200.782,
    "end": 201.076
   },
   {
    "word": "bisa",
    "start": 201.076,
    "end": 201.429
   },
   {
    "word": "saja",
    "start": 201.429,
    "end": 201.782
   },
   {
    "word": "membunuhnya.",
    "start": 201.782,
    "end": 202.547
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 94,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 300,
      "y": 1690,
      "scale": 1.2,
      "expression": "fear",
      "pose": "crouch",
      "freeze": true
     },
     {
      "asset": "/characters/german-soldier.png",
      "x": 800,
      "y": 1300,
      "scale": 1.15,
      "expression": "neutral",
      "pose": "aim",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.1,
      1.25
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      60,
      60
     ]
    },
    "effects": {
     "vignette": 0.85
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-66",
  "segment": 66,
  "startFrame": 6087,
  "durationInFrames": 88,
  "holdFrames": 9,
  "visualDuration": 97,
  "lead": 0,
  "fadeOut": 0,
  "text": "Bisa saja memanggil pasukan lain.",
  "background": "/backgrounds/under-tank.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 300,
    "y": 1690,
    "scale": 1.15,
    "expression": "fear",
    "pose": "crouch",
    "freeze": true
   },
   {
    "asset": "/characters/german-soldier.png",
    "x": 800,
    "y": 1300,
    "scale": 1.15,
    "expression": "neutral",
    "pose": "stand"
   },
   {
    "asset": "/characters/enemy-troops.png",
    "x": 1000,
    "y": 1180,
    "scale": 0.6,
    "expression": "neutral",
    "pose": "stand",
    "enter": "fade"
   }
  ],
  "effects": {
   "vignette": 0.8,
   "dust": 0.5
  },
  "voiceOver": "/audio/voiceover/segments/66.wav",
  "subtitles": [
   {
    "word": "Bisa",
    "start": 202.884,
    "end": 203.345
   },
   {
    "word": "saja",
    "start": 203.345,
    "end": 203.806
   },
   {
    "word": "memanggil",
    "start": 203.806,
    "end": 204.651
   },
   {
    "word": "pasukan",
    "start": 204.651,
    "end": 205.342
   },
   {
    "word": "lain.",
    "start": 205.342,
    "end": 205.803
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 97,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 300,
      "y": 1690,
      "scale": 1.15,
      "expression": "fear",
      "pose": "crouch",
      "freeze": true
     },
     {
      "asset": "/characters/german-soldier.png",
      "x": 800,
      "y": 1300,
      "scale": 1.15,
      "expression": "neutral",
      "pose": "stand"
     },
     {
      "asset": "/characters/enemy-troops.png",
      "x": 1000,
      "y": 1180,
      "scale": 0.6,
      "expression": "neutral",
      "pose": "stand",
      "enter": "fade"
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.05
     ],
     "panX": [
      0,
      -30
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.8,
     "dust": 0.5
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-67",
  "segment": 67,
  "startFrame": 6184,
  "durationInFrames": 61,
  "holdFrames": 15,
  "visualDuration": 76,
  "lead": 0,
  "fadeOut": 0,
  "text": "Tapi dia tidak melakukan keduanya.",
  "background": "/backgrounds/under-tank.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 300,
    "y": 1690,
    "scale": 1.15,
    "expression": "fear",
    "pose": "crouch",
    "freeze": true
   },
   {
    "asset": "/characters/german-soldier.png",
    "x": 800,
    "y": 1300,
    "scale": 1.2,
    "expression": "tired",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.85
  },
  "voiceOver": "/audio/voiceover/segments/67.wav",
  "subtitles": [
   {
    "word": "Tapi",
    "start": 206.121,
    "end": 206.436
   },
   {
    "word": "dia",
    "start": 206.436,
    "end": 206.699
   },
   {
    "word": "tidak",
    "start": 206.699,
    "end": 207.067
   },
   {
    "word": "melakukan",
    "start": 207.067,
    "end": 207.645
   },
   {
    "word": "keduanya.",
    "start": 207.645,
    "end": 208.171
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 76,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 300,
      "y": 1690,
      "scale": 1.15,
      "expression": "fear",
      "pose": "crouch",
      "freeze": true
     },
     {
      "asset": "/characters/german-soldier.png",
      "x": 800,
      "y": 1300,
      "scale": 1.2,
      "expression": "tired",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.05,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.85
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-68",
  "segment": 68,
  "startFrame": 6260,
  "durationInFrames": 66,
  "holdFrames": 10,
  "visualDuration": 76,
  "lead": 0,
  "fadeOut": 0,
  "text": "Dia hanya melihat prajurit itu...",
  "background": "/backgrounds/under-tank.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 250,
    "y": 1700,
    "scale": 1.1,
    "expression": "fear",
    "pose": "crouch",
    "freeze": true
   },
   {
    "asset": "/characters/german-soldier.png",
    "x": 700,
    "y": 1280,
    "scale": 1.45,
    "expression": "tired",
    "pose": "stand",
    "flip": true
   }
  ],
  "effects": {
   "vignette": 0.8
  },
  "voiceOver": "/audio/voiceover/segments/68.wav",
  "subtitles": [
   {
    "word": "Dia",
    "start": 208.665,
    "end": 208.972
   },
   {
    "word": "hanya",
    "start": 208.972,
    "end": 209.401
   },
   {
    "word": "melihat",
    "start": 209.401,
    "end": 209.954
   },
   {
    "word": "prajurit",
    "start": 209.954,
    "end": 210.567
   },
   {
    "word": "itu...",
    "start": 210.567,
    "end": 210.874
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 76,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 250,
      "y": 1700,
      "scale": 1.1,
      "expression": "fear",
      "pose": "crouch",
      "freeze": true
     },
     {
      "asset": "/characters/german-soldier.png",
      "x": 700,
      "y": 1280,
      "scale": 1.45,
      "expression": "tired",
      "pose": "stand",
      "flip": true
     }
    ],
    "camera": {
     "zoom": [
      1.1,
      1.3
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      60,
      55
     ]
    },
    "effects": {
     "vignette": 0.8
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-69",
  "segment": 69,
  "startFrame": 6336,
  "durationInFrames": 29,
  "holdFrames": 13,
  "visualDuration": 42,
  "lead": 0,
  "fadeOut": 0,
  "text": "lalu pergi.",
  "background": "/backgrounds/under-tank.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 300,
    "y": 1690,
    "scale": 1.15,
    "expression": "fear",
    "pose": "crouch",
    "freeze": true
   },
   {
    "asset": "/characters/german-soldier.png",
    "x": 780,
    "y": 1300,
    "scale": 1.15,
    "expression": "neutral",
    "pose": "stand",
    "exit": "slide-right",
    "exitAt": 4,
    "exitDur": 24
   }
  ],
  "effects": {
   "vignette": 0.8,
   "dust": 0.4
  },
  "voiceOver": "/audio/voiceover/segments/69.wav",
  "subtitles": [
   {
    "word": "lalu",
    "start": 211.209,
    "end": 211.649
   },
   {
    "word": "pergi.",
    "start": 211.649,
    "end": 212.163
   }
  ],
  "sfx": [
   {
    "name": "footsteps",
    "at": 0,
    "volume": 0.35
   }
  ],
  "shots": [
   {
    "offset": 0,
    "duration": 42,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 300,
      "y": 1690,
      "scale": 1.15,
      "expression": "fear",
      "pose": "crouch",
      "freeze": true
     },
     {
      "asset": "/characters/german-soldier.png",
      "x": 780,
      "y": 1300,
      "scale": 1.15,
      "expression": "neutral",
      "pose": "stand",
      "exit": "slide-right",
      "exitAt": 4,
      "exitDur": 24
     }
    ],
    "camera": {
     "zoom": [
      1.15,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.8,
     "dust": 0.4
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-70",
  "segment": 70,
  "startFrame": 6378,
  "durationInFrames": 75,
  "holdFrames": 11,
  "visualDuration": 86,
  "lead": 0,
  "fadeOut": 0,
  "text": "Dan di sinilah twist sebenarnya terjadi.",
  "background": "/backgrounds/under-tank.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 540,
    "y": 1680,
    "scale": 1.2,
    "expression": "fear",
    "pose": "crouch",
    "freeze": true
   }
  ],
  "effects": {
   "vignette": 0.7,
   "tint": "rgba(255,230,180,0.08)",
   "flash": [
    0,
    34
   ],
   "shakePulses": [
    0
   ],
   "pulseAmp": 14
  },
  "voiceOver": "/audio/voiceover/segments/70.wav",
  "subtitles": [
   {
    "word": "Dan",
    "start": 212.6,
    "end": 212.871
   },
   {
    "word": "di",
    "start": 212.871,
    "end": 213.087
   },
   {
    "word": "sinilah",
    "start": 213.087,
    "end": 213.574
   },
   {
    "word": "twist",
    "start": 213.574,
    "end": 213.953
   },
   {
    "word": "sebenarnya",
    "start": 213.953,
    "end": 214.602
   },
   {
    "word": "terjadi.",
    "start": 214.602,
    "end": 215.089
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 86,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 540,
      "y": 1680,
      "scale": 1.2,
      "expression": "fear",
      "pose": "crouch",
      "freeze": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.25
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.7,
     "tint": "rgba(255,230,180,0.08)",
     "flash": [
      0,
      34
     ],
     "shakePulses": [
      0
     ],
     "pulseAmp": 14
    },
    "transition": "cut"
   }
  ]
 },
 {
  "id": "scene-71",
  "segment": 71,
  "startFrame": 6464,
  "durationInFrames": 222,
  "holdFrames": 0,
  "visualDuration": 222,
  "lead": 0,
  "fadeOut": 24,
  "text": "Tentara Jerman itu ternyata tidak jauh berbeda dari prajurit yang sedang bersembunyi di hadapannya.",
  "background": "/backgrounds/under-tank.png",
  "characters": [
   {
    "asset": "/characters/new-soldier.png",
    "x": 270,
    "y": 1560,
    "scale": 1.45,
    "expression": "fear",
    "pose": "stand",
    "freeze": true
   },
   {
    "asset": "/characters/german-soldier.png",
    "x": 810,
    "y": 1560,
    "scale": 1.45,
    "expression": "fear",
    "pose": "stand",
    "flip": true,
    "freeze": true
   }
  ],
  "effects": {
   "vignette": 0.75
  },
  "voiceOver": "/audio/voiceover/segments/71.wav",
  "subtitles": [
   {
    "word": "Tentara",
    "start": 215.466,
    "end": 216.054
   },
   {
    "word": "Jerman",
    "start": 216.054,
    "end": 216.577
   },
   {
    "word": "itu",
    "start": 216.577,
    "end": 216.904
   },
   {
    "word": "ternyata",
    "start": 216.904,
    "end": 217.558
   },
   {
    "word": "tidak",
    "start": 217.558,
    "end": 218.016
   },
   {
    "word": "jauh",
    "start": 218.016,
    "end": 218.408
   },
   {
    "word": "berbeda",
    "start": 218.408,
    "end": 218.997
   },
   {
    "word": "dari",
    "start": 218.997,
    "end": 219.389
   },
   {
    "word": "prajurit",
    "start": 219.389,
    "end": 220.043
   },
   {
    "word": "yang",
    "start": 220.043,
    "end": 220.435
   },
   {
    "word": "sedang",
    "start": 220.435,
    "end": 220.958
   },
   {
    "word": "bersembunyi",
    "start": 220.958,
    "end": 221.808
   },
   {
    "word": "di",
    "start": 221.808,
    "end": 222.069
   },
   {
    "word": "hadapannya.",
    "start": 222.069,
    "end": 222.854
   }
  ],
  "sfx": [],
  "shots": [
   {
    "offset": 0,
    "duration": 100,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 270,
      "y": 1560,
      "scale": 1.45,
      "expression": "fear",
      "pose": "stand",
      "freeze": true
     },
     {
      "asset": "/characters/german-soldier.png",
      "x": 810,
      "y": 1560,
      "scale": 1.45,
      "expression": "fear",
      "pose": "stand",
      "flip": true,
      "freeze": true
     }
    ],
    "camera": {
     "zoom": [
      1.0,
      1.1
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.75
    },
    "transition": "cut"
   },
   {
    "offset": 100,
    "duration": 70,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 270,
      "y": 1620,
      "scale": 1.45,
      "expression": "tired",
      "pose": "stand",
      "freeze": true
     },
     {
      "asset": "/characters/german-soldier.png",
      "x": 810,
      "y": 1620,
      "scale": 1.45,
      "expression": "tired",
      "pose": "stand",
      "flip": true,
      "freeze": true
     }
    ],
    "camera": {
     "zoom": [
      1.05,
      1.15
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.75
    },
    "transition": "fade"
   },
   {
    "offset": 170,
    "duration": 52,
    "background": "/backgrounds/under-tank.png",
    "characters": [
     {
      "asset": "/characters/new-soldier.png",
      "x": 270,
      "y": 1560,
      "scale": 1.45,
      "expression": "sad",
      "pose": "stand",
      "freeze": true
     },
     {
      "asset": "/characters/german-soldier.png",
      "x": 810,
      "y": 1560,
      "scale": 1.45,
      "expression": "sad",
      "pose": "stand",
      "flip": true,
      "freeze": true
     }
    ],
    "camera": {
     "zoom": [
      1.15,
      1.05
     ],
     "panX": [
      0,
      0
     ],
     "panY": [
      0,
      0
     ],
     "origin": [
      50,
      55
     ]
    },
    "effects": {
     "vignette": 0.8
    },
    "transition": "fade"
   }
  ]
 }
];

export const TOTAL_FRAMES = 6686;
export const FPS = 30;

export default scenes;
