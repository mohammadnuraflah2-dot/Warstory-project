// Pengaturan utama proyek.
export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

// true  = karakter & background digambar otomatis (placeholder) -> proyek langsung bisa dirender.
// false = pakai file PNG asli di public/characters dan public/backgrounds.
export const USE_PLACEHOLDER_ART = true;

// Matikan sampai file musik / sfx benar-benar ada di public/.
export const ENABLE_MUSIC = false;
export const ENABLE_SFX = false;

export const VOICEOVER_FILE = '/audio/voiceover/master.wav';
export const MUSIC_FILE = '/music/war-theme.mp3'; // placeholder nama file
export const SFX_FILES = {
  'tank-engine': '/sfx/tank-engine.mp3',
  gunfire: '/sfx/gunfire.mp3',
  cannon: '/sfx/cannon.mp3',
  explosion: '/sfx/explosion.mp3',
  footsteps: '/sfx/footsteps.mp3',
  'bullet-impact': '/sfx/bullet-impact.mp3',
  'metal-impact': '/sfx/metal-impact.mp3',
  reload: '/sfx/reload.mp3',
  debris: '/sfx/debris.mp3',
  ambience: '/sfx/ambience.mp3',
};

export const CROSSFADE_FRAMES = 8;
export const SUBTITLE_Y_PERCENT = 70;
