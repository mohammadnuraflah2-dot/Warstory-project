import React from 'react';
import {AbsoluteFill, Audio, Composition, Sequence, interpolate, staticFile} from 'remotion';
import {scenes} from './scenes.js';
import {Scene} from './Scene.jsx';
import {WordSubtitle} from './WordSubtitle.jsx';
import {
  ENABLE_MUSIC,
  ENABLE_SFX,
  FPS,
  HEIGHT,
  MUSIC_FILE,
  SFX_FILES,
  VOICEOVER_FILE,
  WIDTH,
} from './config.js';

const file = (p) => staticFile(p.replace(/^\//, ''));

// Durasi total dihitung dari data scene (yang berasal dari timings.json): 6686 frame.
const last = scenes[scenes.length - 1];
const TOTAL = last.startFrame + last.visualDuration;

// Semua kata subtitle (detik absolut) dari semua scene.
const ALL_WORDS = scenes.flatMap((s) => s.subtitles);

// Kurva volume musik (0.10 - 0.15), mengikuti emosi cerita. Frame = frame segmen dari timings.json.
const MUSIC_CURVE = [
  [0, 0.1], // tegang & misterius
  [1781, 0.12], // mulai menembak: perlahan meningkat
  [2517, 0.12], // misi: serius
  [3036, 0.14], // pasukan musuh muncul: intens
  [4312, 0.15], // pertempuran: intens
  [4791, 0.13], // awak gugur: emosional
  [5583, 0.12], // bersembunyi: sangat tegang
  [6336, 0.1], // tentara Jerman pergi: suspense
  [6378, 0.15], // twist: dramatic reveal
  [TOTAL, 0.12],
];

const musicVolume = (f) =>
  interpolate(
    f,
    MUSIC_CURVE.map((p) => p[0]),
    MUSIC_CURVE.map((p) => p[1]),
    {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'},
  );

const WarStory = () => {
  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      {/* Scene visual berurutan 01 -> 71. Scene 'fade' mulai `lead` frame lebih awal (crossfade 8 frame). */}
      {scenes.map((scene) => (
        <Sequence
          key={scene.id}
          from={scene.startFrame - scene.lead}
          durationInFrames={scene.visualDuration + scene.lead}
          name={scene.id}
        >
          <Scene scene={scene} />
        </Sequence>
      ))}

      {/* Subtitle satu kata, timing absolut dari master.srt / timings.json */}
      <WordSubtitle words={ALL_WORDS} />

      {/* SFX (opsional, aktifkan di config.js bila file sudah ada) */}
      {ENABLE_SFX
        ? scenes.flatMap((scene) =>
            scene.sfx.map((s, i) => (
              <Sequence key={`${scene.id}-sfx-${i}`} from={scene.startFrame + s.at} durationInFrames={FPS * 4}>
                <Audio src={file(SFX_FILES[s.name])} volume={s.volume} />
              </Sequence>
            )),
          )
        : null}

      {/* Musik latar volume rendah (opsional) */}
      {ENABLE_MUSIC ? <Audio src={file(MUSIC_FILE)} loop volume={musicVolume} /> : null}

      {/* VOICE OVER UTAMA: master.wav diputar SATU KALI dari frame 0, tanpa dipotong / diubah kecepatannya */}
      <Audio src={file(VOICEOVER_FILE)} volume={1} />
    </AbsoluteFill>
  );
};

export const RemotionRoot = () => {
  return (
    <Composition
      id="WarStory"
      component={WarStory}
      durationInFrames={TOTAL}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
    />
  );
};
