import React from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {SUBTITLE_Y_PERCENT} from './config.js';

// words = [{word, start, end}]  (detik, absolut dari frame 0)
export const WordSubtitle = ({words}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;

  const active = words.find((w) => t >= w.start && t < w.end);
  if (!active) return null;

  // Kata panjang diperkecil otomatis supaya tidak keluar layar 1080px.
  const fontSize = Math.min(108, Math.floor(960 / (active.word.length * 0.7)));
  const startFrame = Math.round(active.start * fps);
  const s = spring({frame: frame - startFrame, fps, config: {damping: 11, stiffness: 220, mass: 0.6}});
  const scale = 0.7 + 0.3 * Math.min(1.15, s);

  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <div
        style={{
          position: 'absolute',
          top: `${SUBTITLE_Y_PERCENT}%`,
          left: 0,
          right: 0,
          textAlign: 'center',
          transform: `translateY(-50%) scale(${scale})`,
          fontFamily: "'Arial Black', Impact, 'Helvetica Neue', Arial, sans-serif",
          fontWeight: 900,
          fontSize,
          whiteSpace: 'nowrap',
          color: '#fff',
          WebkitTextStroke: '10px #000',
          paintOrder: 'stroke fill',
          textShadow: '0 6px 0 #000, 0 0 18px rgba(0,0,0,0.8)',
          letterSpacing: 1,
        }}
      >
        {active.word}
      </div>
    </AbsoluteFill>
  );
};
