import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {Background} from './Background.jsx';
import {Character} from './Character.jsx';
import {Effects} from './Effects.jsx';
import {CROSSFADE_FRAMES} from './config.js';

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const lerp = (a, b, t) => a + (b - a) * t;

const shakeOffset = (f, fx) => {
  let amp = fx.shake || 0;
  (fx.shakePulses || []).forEach((p) => {
    const d = f - p;
    if (d >= 0 && d < 14) amp += (fx.pulseAmp || 14) * Math.exp(-d / 4);
  });
  if (amp <= 0.01) return {x: 0, y: 0};
  return {
    x: Math.sin(f * 2.31) * amp + Math.sin(f * 5.1) * amp * 0.4,
    y: Math.cos(f * 1.87) * amp * 0.8 + Math.sin(f * 4.3) * amp * 0.3,
  };
};

const ShotView = ({shot, f}) => {
  const dur = Math.max(1, shot.duration);
  const p = Easing.inOut(Easing.quad)(clamp(f / dur, 0, 1));
  const cam = shot.camera;
  const zoom = lerp(cam.zoom[0], cam.zoom[1], p);
  const panX = lerp(cam.panX[0], cam.panX[1], p);
  const panY = lerp(cam.panY[0], cam.panY[1], p);
  const origin = `${cam.origin[0]}% ${cam.origin[1]}%`;
  const sh = shakeOffset(f, shot.effects || {});
  const chars = [...shot.characters].sort((a, b) => a.y - b.y);

  return (
    <AbsoluteFill style={{transform: `translate(${sh.x}px, ${sh.y}px) scale(1.04)`}}>
      <Background name={shot.background} camera={{zoom, panX, panY, origin: cam.origin}} frame={f} />
      <AbsoluteFill style={{transformOrigin: origin, transform: `translate(${panX * 1.25}px, ${panY * 1.25}px) scale(${zoom})`}}>
        {chars.map((c, i) => (
          <Character key={i} {...c} frame={f} />
        ))}
      </AbsoluteFill>
      <Effects effects={shot.effects} frame={f} />
    </AbsoluteFill>
  );
};

// Frame lokal Sequence: 0..lead = fade-in (sebelum startFrame suara), lalu scene berjalan normal.
export const Scene = ({scene}) => {
  const raw = useCurrentFrame();
  const local = raw - scene.lead;
  const f = Math.max(0, local);

  let idx = 0;
  scene.shots.forEach((s, i) => {
    if (f >= s.offset) idx = i;
  });
  const shot = scene.shots[idx];
  const into = f - shot.offset;
  const prev = idx > 0 ? scene.shots[idx - 1] : null;
  const crossfading = prev && shot.transition === 'fade' && into < CROSSFADE_FRAMES;

  const sceneOpacity = scene.lead > 0 ? interpolate(raw, [0, scene.lead], [0, 1], {extrapolateRight: 'clamp'}) : 1;
  const fadeOut =
    scene.fadeOut > 0
      ? interpolate(local, [scene.visualDuration - scene.fadeOut, scene.visualDuration], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})
      : 0;

  return (
    <AbsoluteFill style={{opacity: sceneOpacity, backgroundColor: '#000'}}>
      {crossfading ? <ShotView shot={prev} f={f - prev.offset} /> : null}
      <AbsoluteFill style={{opacity: crossfading ? interpolate(into, [0, CROSSFADE_FRAMES], [0, 1]) : 1}}>
        <ShotView shot={shot} f={into} />
      </AbsoluteFill>
      {fadeOut > 0 ? <AbsoluteFill style={{backgroundColor: '#000', opacity: fadeOut}} /> : null}
    </AbsoluteFill>
  );
};
