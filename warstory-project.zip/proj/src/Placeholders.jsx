import React from 'react';

// Ukuran dasar (px pada scale 1) tiap peran. Dipakai juga oleh Character untuk aset PNG asli.
export const ROLE_SIZE = {
  default: [400, 560],
  tank: [640, 380],
  'enemy-troops': [560, 420],
};

export const roleFromAsset = (asset = '') => {
  const base = asset.split('/').pop().replace(/\.[a-z]+$/i, '');
  return base || 'new-soldier';
};

const PAL = {
  'new-soldier': {body: '#5f8a46', helmet: '#4b7036', accent: '#c9d6a0'},
  'tank-commander': {body: '#3a4d3a', helmet: '#26332a', accent: '#d4af37'},
  'veteran-crew': {body: '#8c6b44', helmet: '#6a4f31', accent: '#d9c08a'},
  'german-soldier': {body: '#6f7782', helmet: '#454a53', accent: '#b8bec7'},
};

const SKIN = '#f1c9a0';

const Face = ({expression}) => {
  const eye = (cx, r = 10) => <circle cx={cx} cy="185" r={r} fill="#000" stroke="none" />;
  const bigEye = (cx, r) => (
    <g>
      <circle cx={cx} cy="185" r={r} fill="#fff" strokeWidth="6" />
      <circle cx={cx} cy="187" r="6" fill="#000" stroke="none" />
    </g>
  );
  switch (expression) {
    case 'fear':
      return (
        <g fill="none">
          {bigEye(155, 17)}
          {bigEye(245, 17)}
          <path d="M132 152 L172 138 M268 152 L228 138" strokeWidth="8" />
          <path d="M165 252 Q185 238 200 252 Q215 266 235 252" strokeWidth="8" />
        </g>
      );
    case 'shock':
      return (
        <g fill="none">
          {bigEye(155, 20)}
          {bigEye(245, 20)}
          <path d="M132 146 L172 134 M268 146 L228 134" strokeWidth="8" />
          <ellipse cx="200" cy="255" rx="18" ry="24" fill="#5a1a1a" strokeWidth="8" />
        </g>
      );
    case 'grim':
      return (
        <g fill="none">
          {eye(155, 8)}
          {eye(245, 8)}
          <path d="M130 146 L175 163 M270 146 L225 163" strokeWidth="10" />
          <path d="M170 258 Q200 240 230 258" strokeWidth="8" />
        </g>
      );
    case 'resolve':
      return (
        <g fill="none">
          {eye(155, 9)}
          {eye(245, 9)}
          <path d="M132 152 L176 156 M268 152 L224 156" strokeWidth="9" />
          <path d="M175 250 L225 246" strokeWidth="8" />
        </g>
      );
    case 'tired':
    case 'sad':
      return (
        <g fill="none">
          <path d="M138 188 L172 192 M262 188 L228 192" strokeWidth="9" />
          <path d="M135 162 L172 148 M265 162 L228 148" strokeWidth="8" />
          <path d="M170 258 Q200 244 230 258" strokeWidth="8" />
        </g>
      );
    default:
      return (
        <g fill="none">
          {eye(155)}
          {eye(245)}
          <path d="M172 248 L228 248" strokeWidth="8" />
        </g>
      );
  }
};

const Soldier = ({role, expression, pose}) => {
  const pal = PAL[role] || PAL['new-soldier'];
  return (
    <svg viewBox="0 0 400 560" width="100%" height="100%">
      <g stroke="#000" strokeWidth="10" strokeLinejoin="round" strokeLinecap="round">
        <rect x="150" y="440" width="45" height="90" rx="14" fill={pal.body} />
        <rect x="205" y="440" width="45" height="90" rx="14" fill={pal.body} />
        <rect x="138" y="518" width="65" height="30" rx="12" fill="#222" />
        <rect x="197" y="518" width="65" height="30" rx="12" fill="#222" />
        <rect x="100" y="322" width="40" height="120" rx="18" fill={pal.body} />
        <rect x="130" y="290" width="140" height="165" rx="40" fill={pal.body} />
        <rect x="132" y="400" width="136" height="16" fill={pal.accent} />
        {pose === 'aim' ? (
          <g>
            <rect x="250" y="320" width="135" height="38" rx="18" fill={pal.body} />
            <rect x="290" y="296" width="105" height="16" rx="6" fill="#333" />
          </g>
        ) : (
          <rect x="260" y="322" width="40" height="120" rx="18" fill={pal.body} />
        )}
        <circle cx="200" cy="170" r="125" fill={SKIN} />
        <path d="M76 165 A125 125 0 0 1 324 165 Q200 128 76 165 Z" fill={pal.helmet} />
        <rect x="150" y="128" width="100" height="14" rx="6" fill={pal.accent} />
        <Face expression={expression} />
      </g>
    </svg>
  );
};

const Mini = ({x, y, s, shade}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} stroke="#000" strokeWidth="7" strokeLinejoin="round">
    <rect x="-22" y="40" width="44" height="60" rx="14" fill={shade} />
    <rect x="-30" y="48" width="60" height="6" fill="#222" />
    <circle cx="0" cy="10" r="36" fill={SKIN} />
    <path d="M-38 12 A38 38 0 0 1 38 12 Q0 0 -38 12 Z" fill="#454a53" />
    <rect x="18" y="52" width="46" height="8" fill="#222" />
  </g>
);

const Crowd = () => {
  const rows = [
    {y: 130, s: 0.55, shade: '#555b66', n: 9},
    {y: 200, s: 0.75, shade: '#4d525c', n: 7},
    {y: 270, s: 1, shade: '#444952', n: 5},
  ];
  return (
    <svg viewBox="0 0 560 420" width="100%" height="100%">
      {rows.map((r, ri) =>
        Array.from({length: r.n}).map((_, i) => (
          <Mini key={`${ri}-${i}`} x={40 + i * (480 / (r.n - 1 || 1))} y={r.y + (i % 2) * 8} s={r.s} shade={r.shade} />
        )),
      )}
    </svg>
  );
};

const Tank = () => (
  <svg viewBox="0 0 640 380" width="100%" height="100%">
    <g stroke="#000" strokeWidth="10" strokeLinejoin="round" strokeLinecap="round">
      <rect x="40" y="250" width="560" height="100" rx="46" fill="#2c3036" />
      {[110, 200, 290, 380, 470, 550].map((cx) => (
        <circle key={cx} cx={cx} cy="300" r="30" fill="#4a4f57" />
      ))}
      <rect x="80" y="170" width="480" height="90" rx="14" fill="#5a6b4a" />
      <rect x="200" y="90" width="230" height="90" rx="24" fill="#667a54" />
      <rect x="420" y="118" width="215" height="22" rx="8" fill="#3d4a33" />
      <circle cx="315" cy="75" r="22" fill="#4f5f40" />
    </g>
  </svg>
);

export const PlaceholderCharacter = ({role, expression, pose}) => {
  if (role === 'tank') return <Tank />;
  if (role === 'enemy-troops') return <Crowd />;
  return <Soldier role={role} expression={expression} pose={pose} />;
};

// ---------------- Background placeholder (3 layer untuk parallax) ----------------

const Layer = ({factor, camera, children}) => {
  const z = 1 + (camera.zoom - 1) * factor;
  return (
    <div
      style={{
        position: 'absolute',
        left: -160,
        top: -100,
        width: 1400,
        height: 2120,
        transformOrigin: `${camera.origin[0]}% ${camera.origin[1]}%`,
        transform: `translate(${camera.panX * factor}px, ${camera.panY * factor}px) scale(${z})`,
      }}
    >
      <svg width="1400" height="2120" viewBox="0 0 1400 2120">
        {children}
      </svg>
    </div>
  );
};

const Grad = ({id, stops}) => (
  <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
    {stops.map(([o, c], i) => (
      <stop key={i} offset={o} stopColor={c} />
    ))}
  </linearGradient>
);

const TankInterior = ({camera, frame}) => (
  <>
    <Layer factor={0.35} camera={camera}>
      <defs>
        <Grad id="ti-w" stops={[[0, '#3a424b'], [1, '#14181c']]} />
        <radialGradient id="ti-l">
          <stop offset="0" stopColor="#f6dc94" stopOpacity="0.9" />
          <stop offset="1" stopColor="#f6dc94" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="1400" height="2120" fill="url(#ti-w)" />
      {[0, 1, 2, 3, 4, 5, 6].map((i) => (
        <rect key={i} x={i * 200} y="0" width="6" height="2120" fill="#0e1114" />
      ))}
      <circle cx="700" cy="260" r={210 + Math.sin(frame / 15) * 6} fill="url(#ti-l)" />
    </Layer>
    <Layer factor={0.7} camera={camera}>
      <rect x="60" y="640" width="320" height="760" rx="20" fill="#2a2f35" stroke="#0b0d0f" strokeWidth="8" />
      {[0, 1, 2, 3, 4].map((r) =>
        [0, 1, 2].map((c) => <circle key={`${r}${c}`} cx={130 + c * 100} cy={730 + r * 135} r="40" fill="#8a7a3a" stroke="#0b0d0f" strokeWidth="7" />),
      )}
      <rect x="0" y="520" width="1400" height="40" fill="#1f2328" />
      <rect x="1000" y="700" width="260" height="420" rx="16" fill="#22272d" stroke="#0b0d0f" strokeWidth="8" />
      <rect x="1040" y="740" width="180" height="120" rx="10" fill="#6aa0a8" opacity="0.5" />
    </Layer>
    <Layer factor={1.2} camera={camera}>
      <rect x="0" y="1760" width="1400" height="360" fill="#1b1e22" />
      <rect x="0" y="1740" width="1400" height="30" fill="#2d3238" />
    </Layer>
  </>
);

const Battlefield = ({camera, frame}) => (
  <>
    <Layer factor={0.3} camera={camera}>
      <defs>
        <Grad id="bf-s" stops={[[0, '#e08a3c'], [0.5, '#6a3b2e'], [1, '#2a2226']]} />
      </defs>
      <rect width="1400" height="2120" fill="url(#bf-s)" />
      <circle cx="900" cy="760" r="130" fill="#ffd58a" opacity="0.8" />
      {[0, 1, 2].map((i) => (
        <ellipse key={i} cx={300 + i * 380 + Math.sin((frame + i * 30) / 50) * 20} cy={620 - i * 40} rx="90" ry="360" fill="#2f2a2b" opacity="0.7" />
      ))}
    </Layer>
    <Layer factor={0.7} camera={camera}>
      <polygon points="0,1180 220,1080 480,1160 760,1050 1060,1150 1400,1070 1400,1500 0,1500" fill="#3d3a33" />
      <polygon points="880,1100 880,900 960,860 1010,930 1090,900 1090,1100" fill="#2a2724" stroke="#0e0d0c" strokeWidth="6" />
      <path d="M200 1100 L200 900 M200 960 L140 900 M200 990 L270 930" stroke="#1a1614" strokeWidth="12" fill="none" />
    </Layer>
    <Layer factor={1.2} camera={camera}>
      <polygon points="0,1500 1400,1440 1400,2120 0,2120" fill="#2d2a24" />
      <ellipse cx="330" cy="1750" rx="230" ry="46" fill="#1d1b17" />
      <ellipse cx="1000" cy="1880" rx="280" ry="56" fill="#1d1b17" />
      {[0, 1, 2, 3, 4].map((i) => (
        <rect key={i} x={80 + i * 110} y="1560" width="100" height="46" rx="20" fill="#6b5d45" stroke="#0e0d0c" strokeWidth="6" />
      ))}
    </Layer>
  </>
);

const Crossroads = ({camera, frame}) => (
  <>
    <Layer factor={0.3} camera={camera}>
      <defs>
        <Grad id="cr-s" stops={[[0, '#d6935a'], [0.5, '#5b4a62'], [1, '#232a3d']]} />
      </defs>
      <rect width="1400" height="2120" fill="url(#cr-s)" />
      <circle cx="420" cy="900" r="110" fill="#ffd9a0" opacity="0.7" />
      <ellipse cx={1000 + Math.sin(frame / 60) * 30} cy="520" rx="260" ry="70" fill="#7a6a78" opacity="0.5" />
    </Layer>
    <Layer factor={0.7} camera={camera}>
      <rect x="0" y="1000" width="1400" height="300" fill="#4d5a34" />
      <rect x="0" y="1120" width="1400" height="200" fill="#3d4a2b" />
      {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
        <ellipse key={i} cx={100 + i * 190} cy="1000" rx="110" ry="70" fill="#25301f" />
      ))}
      <rect x="1030" y="1000" width="14" height="190" fill="#3a2d20" />
      <rect x="980" y="1010" width="120" height="44" fill="#6a5238" stroke="#0e0d0c" strokeWidth="5" />
    </Layer>
    <Layer factor={1.2} camera={camera}>
      <polygon points="640,1180 760,1180 1240,2120 160,2120" fill="#7a6648" />
      <polygon points="0,1560 1400,1560 1400,1700 0,1700" fill="#6f5c40" />
      <polygon points="0,1700 1400,1700 1400,2120 0,2120" fill="#6b5a3f" opacity="0.0" />
      {[0, 1, 2, 3].map((i) => (
        <rect key={i} x={60 + i * 120} y="1840" width="100" height="46" rx="20" fill="#6b5d45" stroke="#0e0d0c" strokeWidth="6" />
      ))}
    </Layer>
  </>
);

const UnderTank = ({camera, frame}) => (
  <>
    <Layer factor={0.3} camera={camera}>
      <defs>
        <Grad id="ut-s" stops={[[0, '#c9a56b'], [1, '#6b5a44']]} />
      </defs>
      <rect width="1400" height="2120" fill="#17130f" />
      <rect x="0" y="760" width="1400" height="660" fill="url(#ut-s)" />
      <rect x="0" y="1280" width="1400" height="140" fill="#4a3d2d" />
    </Layer>
    <Layer factor={0.7} camera={camera}>
      <polygon points="0,0 1400,0 1400,780 0,780" fill="#121416" />
      {[200, 700, 1200].map((cx) => (
        <circle key={cx} cx={cx} cy="760" r="150" fill="#1d2024" stroke="#050607" strokeWidth="8" />
      ))}
      {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
        <circle key={i} cx={80 + i * 180} cy="420" r="12" fill="#2a2e33" />
      ))}
    </Layer>
    <Layer factor={1.2} camera={camera}>
      <polygon points="0,1420 1400,1380 1400,2120 0,2120" fill="#3b3125" />
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <ellipse key={i} cx={120 + i * 230} cy={1700 + (i % 3) * 90} rx="60" ry="22" fill="#2a2319" />
      ))}
    </Layer>
  </>
);

export const PlaceholderBackground = ({name, camera, frame}) => {
  const key = (name || '').split('/').pop().replace(/\.[a-z]+$/i, '');
  return (
    <div style={{position: 'absolute', inset: 0, overflow: 'hidden', backgroundColor: '#000'}}>
      {key === 'tank-interior' ? <TankInterior camera={camera} frame={frame} /> : null}
      {key === 'battlefield' ? <Battlefield camera={camera} frame={frame} /> : null}
      {key === 'crossroads' ? <Crossroads camera={camera} frame={frame} /> : null}
      {key === 'under-tank' ? <UnderTank camera={camera} frame={frame} /> : null}
    </div>
  );
};
