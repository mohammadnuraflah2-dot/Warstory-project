import React from 'react';
import {AbsoluteFill, interpolate, random} from 'remotion';

const Vignette = ({strength}) => (
  <AbsoluteFill style={{background: `radial-gradient(ellipse at center, rgba(0,0,0,0) 38%, rgba(0,0,0,${strength}) 100%)`}} />
);

const Smoke = ({amount, frame}) => {
  const blobs = [];
  for (let i = 0; i < 7; i++) {
    const speed = 0.7 + i * 0.12;
    const y = 1500 - i * 130 - ((frame * speed + i * 210) % 700);
    const x = ((i * 173) % 1080) - 150 + Math.sin((frame + i * 20) / 40) * 40;
    blobs.push(
      <div
        key={i}
        style={{
          position: 'absolute',
          left: x,
          top: y,
          width: 520,
          height: 520,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(60,56,52,0.9) 0%, rgba(60,56,52,0) 70%)',
          opacity: Math.min(1, amount) * 0.55,
        }}
      />,
    );
  }
  return <AbsoluteFill>{blobs}</AbsoluteFill>;
};

const Dust = ({amount, frame}) => {
  const parts = [];
  for (let i = 0; i < 28; i++) {
    const r1 = random('dx' + i);
    const r2 = random('dy' + i);
    const r3 = random('ds' + i);
    const x = ((r1 * 1180 + frame * (0.6 + r3) * 1.5) % 1180) - 50;
    const y = ((r2 * 2000 + frame * (0.2 + r3) * 0.6) % 2000) - 40;
    const size = 3 + r3 * 7;
    parts.push(
      <div
        key={i}
        style={{
          position: 'absolute',
          left: x,
          top: y,
          width: size,
          height: size,
          borderRadius: '50%',
          backgroundColor: `rgba(232,210,170,${0.5 * Math.min(1, amount) + 0.1})`,
        }}
      />,
    );
  }
  return <AbsoluteFill>{parts}</AbsoluteFill>;
};

const Muzzle = ({offsets, frame, at}) => {
  const out = [];
  offsets.forEach((o, k) => {
    const l = frame - o;
    if (l < 0 || l >= 5) return;
    const s = interpolate(l, [0, 1, 5], [0.5, 1.2, 0.3]);
    const op = interpolate(l, [0, 4, 5], [1, 0.8, 0]);
    out.push(
      <svg
        key={k}
        width="520"
        height="520"
        viewBox="-100 -100 200 200"
        style={{position: 'absolute', left: `${at[0]}%`, top: `${at[1]}%`, marginLeft: -260, marginTop: -260, opacity: op, transform: `scale(${s})`}}
      >
        <polygon
          points="0,-95 18,-30 70,-70 36,-12 98,0 36,12 70,70 18,30 0,95 -18,30 -70,70 -36,12 -98,0 -36,-12 -70,-70 -18,-30"
          fill="#ffb21f"
          stroke="#fff3b0"
          strokeWidth="6"
        />
        <circle r="28" fill="#fffbe0" />
      </svg>,
    );
  });
  return <AbsoluteFill>{out}</AbsoluteFill>;
};

const Impact = ({offsets, frame, at}) => {
  const out = [];
  offsets.forEach((o, k) => {
    const l = frame - o;
    if (l < 0 || l >= 12) return;
    const r = interpolate(l, [0, 12], [20, 280]);
    const op = interpolate(l, [0, 12], [0.95, 0]);
    out.push(
      <svg
        key={k}
        width="640"
        height="640"
        viewBox="-320 -320 640 640"
        style={{position: 'absolute', left: `${at[0]}%`, top: `${at[1]}%`, marginLeft: -320, marginTop: -320, opacity: op}}
      >
        <circle r={r} fill="none" stroke="#ffcf70" strokeWidth="14" />
        <circle r={r * 0.55} fill="rgba(255,140,40,0.55)" />
      </svg>,
    );
  });
  return <AbsoluteFill>{out}</AbsoluteFill>;
};

const Flash = ({offsets, frame}) => {
  let op = 0;
  offsets.forEach((o) => {
    const l = frame - o;
    if (l >= 0) op = Math.max(op, interpolate(l, [0, 1, 7], [0, 0.7, 0], {extrapolateRight: 'clamp'}));
  });
  if (op <= 0) return null;
  return <AbsoluteFill style={{backgroundColor: '#fff2c4', opacity: op}} />;
};

export const Effects = ({effects, frame}) => {
  const fx = effects || {};
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {fx.tint ? <AbsoluteFill style={{backgroundColor: fx.tint}} /> : null}
      {fx.smoke > 0 ? <Smoke amount={fx.smoke} frame={frame} /> : null}
      {fx.dust > 0 ? <Dust amount={fx.dust} frame={frame} /> : null}
      <Muzzle offsets={fx.muzzle || []} frame={frame} at={fx.muzzleAt || [62, 52]} />
      <Impact offsets={fx.impact || []} frame={frame} at={fx.impactAt || [50, 55]} />
      <Flash offsets={fx.flash || []} frame={frame} />
      {fx.vignette > 0 ? <Vignette strength={fx.vignette} /> : null}
    </AbsoluteFill>
  );
};
