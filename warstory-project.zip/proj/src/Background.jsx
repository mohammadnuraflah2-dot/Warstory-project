import React from 'react';
import {AbsoluteFill, Img, staticFile} from 'remotion';
import {USE_PLACEHOLDER_ART} from './config.js';
import {PlaceholderBackground} from './Placeholders.jsx';

// camera = {zoom, panX, panY, origin:[%,%]}
export const Background = ({name, camera, frame = 0}) => {
  if (USE_PLACEHOLDER_ART) {
    return <PlaceholderBackground name={name} camera={camera} frame={frame} />;
  }
  const {zoom, panX, panY, origin} = camera;
  return (
    <AbsoluteFill style={{overflow: 'hidden', backgroundColor: '#000'}}>
      <Img
        src={staticFile(name.replace(/^\//, ''))}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          transformOrigin: `${origin[0]}% ${origin[1]}%`,
          transform: `translate(${panX * 0.8}px, ${panY * 0.8}px) scale(${zoom * 1.08})`,
        }}
      />
    </AbsoluteFill>
  );
};
