#!/usr/bin/env python3
"""Membuat src/scenes.js dari public/audio/voiceover/timings.json.

Semua angka timing (startFrame, durationInFrames, start, end) diambil langsung
dari timings.json. Tidak ada timing yang dikarang.
Jalankan:  python3 tools/build_scenes.py
"""
import json
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VO = os.path.join(ROOT, 'public', 'audio', 'voiceover')
T = json.load(open(os.path.join(VO, 'timings.json'), encoding='utf-8'))
FPS = T['fps']
TOTAL = T['totalFrames']
SEGS = T['segments']

# ---------------------------------------------------------------- aset
NS = '/characters/new-soldier.png'
TC = '/characters/tank-commander.png'
VC = '/characters/veteran-crew.png'
GS = '/characters/german-soldier.png'
EN = '/characters/enemy-troops.png'
TK = '/characters/tank.png'
TI = '/backgrounds/tank-interior.png'
BF = '/backgrounds/battlefield.png'
CR = '/backgrounds/crossroads.png'
UT = '/backgrounds/under-tank.png'


def C(asset, x, y, s=1.0, e='neutral', p='stand', **kw):
    d = {'asset': asset, 'x': x, 'y': y, 'scale': s, 'expression': e, 'pose': p}
    d.update(kw)
    return d


def CAM(z=(1.0, 1.0), px=(0, 0), py=(0, 0), o=(50, 55)):
    return {'zoom': list(z), 'panX': list(px), 'panY': list(py), 'origin': list(o)}


def FX(**kw):
    d = {'vignette': 0.4}
    d.update(kw)
    return d


def SH(at, bg, chars, cam, fx=None, tr='cut'):
    return {'at': at, 'bg': bg, 'chars': chars, 'cam': cam, 'fx': fx or FX(), 'tr': tr}


SPEC = {}


def S(n, *shots, lead=False, sfx=None):
    SPEC[n] = {'shots': list(shots), 'lead': lead, 'sfx': sfx or []}


def sfx(name, at, vol=0.4):
    return {'name': name, 'at': at, 'volume': vol}


WARM = 'rgba(255,170,70,0.10)'
DARK = 'rgba(8,10,22,0.38)'
RED = 'rgba(150,30,20,0.22)'
DUSK = 'rgba(60,30,40,0.18)'

# ---------------------------------------------------------------- 01-10: ragu & komandan
S(1, SH(0, TI, [C(NS, 540, 1560, 1.35, 'fear', 'aim', bob=4)], CAM((1.0, 1.35), o=(50, 40)), FX(vignette=0.5)))
S(2,
  SH(0, TI, [C(NS, 260, 1530, 1.0, 'fear'), C(VC, 620, 1520, 1.2, enter='slide-right'), C(VC, 900, 1500, 1.1, flip=True)],
     CAM((1.0, 1.1), px=(0, -40)), FX(vignette=0.4)),
  SH(95, TI, [C(NS, 300, 1570, 0.85, 'fear'), C(VC, 740, 1570, 1.5, 'grim', flip=True)],
     CAM((1.05, 1.0)), FX(vignette=0.45), 'fade'))
S(3, SH(0, TI, [C(NS, 540, 1540, 1.25)], CAM((1.2, 1.0)), FX(vignette=0.35)))
S(4, SH(0, TI, [C(NS, 540, 1540, 1.3, 'sad')], CAM((1.0, 1.2)), FX(vignette=0.6, tint=DARK)))
S(5, SH(0, TI, [C(NS, 540, 1580, 1.6, 'fear')], CAM((1.1, 1.4), o=(50, 35)), FX(vignette=0.6)))
S(6, SH(0, BF, [C(NS, 260, 1560, 1.2, 'fear', 'aim'), C(EN, 760, 1250, 0.7, enter='fade'),
               C(EN, 910, 1310, 0.9, enter='rise', delay=15)],
        CAM((1.0, 1.05), px=(0, -40)), FX(dust=0.5, vignette=0.4)), lead=True)
S(7,
  SH(0, TI, [C(NS, 400, 1500, 1.4, 'fear', 'aim')], CAM((1.0, 2.5), o=(52, 61)),
     FX(vignette=0.7, shake=1.2)),
  SH(50, TI, [C(NS, 400, 1500, 1.4, 'fear', 'aim', freeze=True)], CAM((2.5, 2.7), o=(52, 61)),
     FX(vignette=0.75, shake=0.3)))
S(8,
  SH(0, TI, [C(VC, 200, 1520, 1.15, 'grim'), C(VC, 880, 1520, 1.15, 'grim', flip=True), C(NS, 540, 1590, 0.8, 'fear')],
     CAM((1.0, 1.05), px=(0, -40)), FX(vignette=0.45)),
  SH(100, TI, [C(VC, 540, 1610, 1.9, 'grim')], CAM((1.0, 1.15)), FX(vignette=0.55)))
S(9, SH(0, TI, [C(TC, 540, 1540, 1.4, 'grim', enter='pop')], CAM((1.0, 1.2)), FX(vignette=0.5)))
S(10,
  SH(0, TI, [C(TC, 760, 1540, 1.3, 'grim', flip=True), C(NS, 300, 1570, 1.0, 'fear')],
     CAM((1.0, 1.05), px=(0, 30)), FX(vignette=0.45)),
  SH(70, TI, [C(NS, 540, 1590, 1.5, 'resolve')], CAM((1.1, 1.35)), FX(vignette=0.55)))

# ---------------------------------------------------------------- 11-19: dipaksa melihat perang, mulai menembak
S(11, SH(0, TI, [C(TC, 300, 1540, 1.4, 'grim'), C(NS, 780, 1580, 1.05, 'fear')],
         CAM((1.0, 1.15), o=(30, 50)), FX(vignette=0.5, shake=0.5)))
S(12, SH(0, BF, [C(TC, 280, 1540, 1.25, 'grim'), C(NS, 720, 1560, 1.1, 'shock'), C(EN, 860, 1220, 0.65, enter='fade', delay=20)],
         CAM((1.0, 1.2)), FX(dust=0.8, smoke=0.5, vignette=0.5, shakePulses=[30, 60], pulseAmp=6)), lead=True)
S(13, SH(0, BF, [C(NS, 540, 1560, 1.4, 'fear')], CAM((1.05, 1.1), px=(0, -30)), FX(smoke=0.6, dust=0.5, vignette=0.5)))
S(14, SH(0, BF, [C(NS, 540, 1500, 0.8, 'fear')], CAM((1.3, 1.0), o=(50, 70)), FX(dust=0.6, vignette=0.55)))
S(15, SH(0, TI, [C(NS, 540, 1560, 1.3, 'tired')], CAM((1.0, 1.12)), FX(vignette=0.5, tint='rgba(20,40,70,0.15)')), lead=True)
S(16,
  SH(0, TI, [C(NS, 540, 1560, 1.35, 'fear')], CAM((1.0, 1.2)), FX(vignette=0.5)),
  SH(85, TI, [C(NS, 400, 1560, 1.3, 'resolve', 'aim'), C(TC, 820, 1540, 1.1, 'grim', flip=True)],
     CAM((1.1, 1.0)), FX(vignette=0.45), 'fade'))
S(17, SH(0, TI, [C(NS, 540, 1520, 1.4, 'resolve', 'aim')], CAM((1.1, 1.2)),
         FX(vignette=0.5, muzzle=[4], muzzleAt=[74, 61], flash=[4], shakePulses=[4], pulseAmp=22)),
  sfx=[sfx('gunfire', 4, 0.5)])
S(18, SH(0, BF, [C(NS, 300, 1540, 1.2, 'resolve', 'aim'), C(EN, 780, 1250, 0.6, exit='fall', exitAt=10, exitDur=16)],
         CAM((1.0, 1.1)), FX(vignette=0.5, muzzle=[3], muzzleAt=[48, 64], shakePulses=[3], pulseAmp=14, dust=0.4)),
  sfx=[sfx('gunfire', 3, 0.45), sfx('bullet-impact', 10, 0.35)])
S(19,
  SH(0, TI, [C(NS, 540, 1560, 1.3, 'resolve'), C(TC, 250, 1540, 1.1, 'grim')], CAM((1.0, 1.15)), FX(vignette=0.5)),
  SH(90, BF, [C(NS, 280, 1540, 1.2, 'resolve', 'aim'), C(EN, 760, 1340, 1.3, enter='rise')],
     CAM((1.0, 1.2)), FX(dust=0.6, vignette=0.5, muzzle=[10, 30], muzzleAt=[46, 64], shakePulses=[10, 30], pulseAmp=8), 'fade'),
  sfx=[sfx('gunfire', 100, 0.4), sfx('gunfire', 120, 0.4)])

# ---------------------------------------------------------------- 20-24: diterima sebagai kru
S(20, SH(0, TI, [C(NS, 540, 1560, 1.2), C(VC, 880, 1520, 1.15, flip=True)], CAM((1.0, 1.1)), FX(vignette=0.4, tint=WARM)), lead=True)
S(21, SH(0, TI, [C(NS, 380, 1560, 1.15), C(VC, 760, 1520, 1.2, flip=True, enter='pop')], CAM((1.0, 1.08)), FX(vignette=0.4, tint=WARM)))
S(22, SH(0, BF, [C(NS, 250, 1540, 1.1, 'resolve', 'aim'), C(VC, 540, 1520, 1.15, 'resolve', 'aim'), C(TC, 830, 1520, 1.15, 'grim', 'aim', flip=True)],
         CAM((1.0, 1.08)), FX(vignette=0.45, muzzle=[8, 26, 40], muzzleAt=[34, 63], shakePulses=[8, 26, 40], pulseAmp=7, dust=0.4)),
  sfx=[sfx('gunfire', 8, 0.4), sfx('gunfire', 26, 0.4)])
S(23, SH(0, TI, [C(NS, 300, 1560, 1.1), C(VC, 620, 1520, 1.15), C(TC, 900, 1520, 1.1, flip=True)], CAM((1.0, 1.04)), FX(vignette=0.4, tint=WARM)))
S(24, SH(0, TI, [C(NS, 250, 1570, 1.0), C(VC, 500, 1530, 1.05), C(TC, 780, 1530, 1.05, flip=True), C(VC, 1000, 1540, 0.95, flip=True)],
         CAM((1.0, 1.15)), FX(vignette=0.45, tint=WARM)))

# ---------------------------------------------------------------- 25-35: misi, kerusakan, pasukan SS muncul
S(25, SH(0, CR, [C(TK, 540, 1500, 0.9)], CAM((1.0, 1.1)), FX(dust=0.4, vignette=0.4)), lead=True,
  sfx=[sfx('tank-engine', 0, 0.35)])
S(26, SH(0, CR, [C(TK, 540, 1380, 0.7), C(TC, 280, 1570, 1.2), C(NS, 760, 1590, 1.1)], CAM((1.0, 1.08), px=(0, -30)), FX(dust=0.4, vignette=0.4)))
S(27,
  SH(0, CR, [C(TK, 540, 1480, 1.1)], CAM((1.2, 1.0)), FX(dust=0.4, vignette=0.45)),
  SH(65, CR, [C(TC, 250, 1560, 1.2, 'resolve'), C(NS, 540, 1590, 1.1, 'resolve'), C(VC, 820, 1540, 1.15, 'resolve', flip=True)],
     CAM((1.0, 1.1)), FX(dust=0.4, vignette=0.5), 'fade'))
S(28, SH(0, CR, [C(TC, 300, 1560, 1.2, 'shock'), C(NS, 760, 1590, 1.1, 'fear')], CAM((1.05, 1.2)),
         FX(dust=1.0, vignette=0.55, tint='rgba(150,60,30,0.18)', shakePulses=[10, 30], pulseAmp=10)),
  sfx=[sfx('explosion', 10, 0.3)])
S(29, SH(0, CR, [C(TK, 540, 1480, 1.2)], CAM((1.0, 1.1)),
         FX(vignette=0.6, smoke=1.0, flash=[4], impact=[4], impactAt=[50, 70], shakePulses=[4], pulseAmp=26)),
  sfx=[sfx('explosion', 4, 0.55), sfx('metal-impact', 4, 0.5)])
S(30, SH(0, TI, [C(NS, 260, 1580, 1.1, 'shock'), C(VC, 640, 1530, 1.15, 'grim'), C(TC, 900, 1530, 1.1, 'grim', flip=True)],
         CAM((1.0, 1.1)), FX(vignette=0.55, smoke=0.7, tint=RED, shakePulses=[20], pulseAmp=8)))
S(31, SH(0, CR, [C(TC, 540, 1540, 1.3, 'grim')], CAM((1.0, 1.15), o=(50, 45)), FX(dust=0.6, vignette=0.6, tint=DUSK)), lead=True)
S(32,
  SH(0, CR, [C(NS, 300, 1580, 1.05, 'shock'), C(TC, 620, 1560, 1.15, 'grim')], CAM((1.0, 1.1)), FX(dust=0.5, vignette=0.55)),
  SH(60, CR, [C(EN, 700, 1180, 0.4, enter='fade'), C(EN, 540, 1190, 0.35, enter='fade', delay=8), C(EN, 880, 1190, 0.38, enter='fade', delay=16)],
     CAM((1.1, 1.4), o=(55, 62)), FX(dust=0.8, vignette=0.6), 'fade'))
S(33, SH(0, CR, [C(EN, 540, 1210, 0.5, enter='fade'), C(EN, 300, 1260, 0.8, enter='fade', delay=15), C(EN, 800, 1290, 0.9, enter='fade', delay=30),
                C(EN, 540, 1430, 1.4, enter='rise', delay=50)],
         CAM((1.35, 1.0)), FX(dust=0.5, vignette=0.5)),
  sfx=[sfx('footsteps', 30, 0.3)])
S(34, SH(0, CR, [C(EN, 540, 1250, 0.9), C(EN, 250, 1300, 0.8), C(EN, 830, 1300, 0.8)], CAM((1.0, 1.1)), FX(dust=0.5, vignette=0.55)))
S(35, SH(0, CR, [C(EN, 200, 1200, 0.6, enter='fade'), C(EN, 540, 1190, 0.65, enter='fade', delay=4), C(EN, 880, 1200, 0.6, enter='fade', delay=8),
                C(EN, 380, 1310, 0.9, enter='fade', delay=12), C(EN, 700, 1310, 0.9, enter='fade', delay=16), C(EN, 540, 1460, 1.3, enter='rise', delay=20)],
         CAM((1.5, 0.92)), FX(dust=0.6, vignette=0.5)))

# ---------------------------------------------------------------- 36-48: bertahan dan bertempur
S(36, SH(0, CR, [C(TC, 280, 1550, 1.1, 'grim'), C(NS, 540, 1580, 1.0, 'fear'), C(VC, 800, 1530, 1.1, 'grim', flip=True), C(EN, 540, 1170, 0.4)],
         CAM((1.0, 1.08)), FX(dust=0.4, vignette=0.55)))
S(37, SH(0, CR, [C(TC, 400, 1540, 1.2, 'tired', flip=True), C(NS, 700, 1580, 1.05, 'fear', flip=True)], CAM((1.0, 1.08), px=(0, 60)), FX(vignette=0.5, dust=0.3)))
S(38, SH(0, CR, [C(TC, 250, 1540, 1.2, 'resolve', 'aim'), C(NS, 520, 1580, 1.05, 'resolve', 'aim'), C(VC, 790, 1520, 1.15, 'resolve', 'aim')],
         CAM((1.0, 1.12), px=(0, -40)), FX(vignette=0.5, dust=0.4)))
S(39, SH(0, TI, [C(TC, 540, 1540, 1.4, 'grim')], CAM((1.0, 1.2)), FX(vignette=0.65, tint=DARK)))
S(40, SH(0, CR, [C(TC, 180, 1560, 0.8, 'grim'), C(NS, 330, 1580, 0.7, 'fear'), C(VC, 470, 1540, 0.8, 'grim'), C(VC, 600, 1540, 0.75, 'grim'),
                C(EN, 820, 1300, 1.2, enter='fade'), C(EN, 900, 1180, 0.8, enter='fade', delay=10)],
         CAM((1.1, 1.0)), FX(dust=0.5, vignette=0.55)))
S(41, SH(0, CR, [C(TK, 540, 1440, 1.3), C(TC, 250, 1570, 0.9, 'grim'), C(NS, 850, 1590, 0.9, 'fear')], CAM((1.0, 1.15)),
         FX(smoke=0.9, vignette=0.6, shakePulses=[20], pulseAmp=6)))
S(42, SH(0, CR, [C(TC, 270, 1540, 1.25, 'resolve'), C(NS, 540, 1570, 1.15, 'resolve'), C(VC, 810, 1520, 1.2, 'resolve', flip=True)],
         CAM((1.0, 1.2)), FX(vignette=0.55, dust=0.3)))
S(43,
  SH(0, CR, [C(TK, 540, 1470, 1.25)], CAM((1.0, 1.15)), FX(smoke=0.5, vignette=0.6, tint='rgba(30,30,25,0.35)')),
  SH(76, CR, [C(TK, 540, 1470, 1.0), C(EN, 700, 1190, 0.5, enter='fade')], CAM((1.15, 1.3), o=(50, 60)),
     FX(dust=0.5, vignette=0.6, tint='rgba(30,30,25,0.3)'), 'fade'))
S(44, SH(0, CR, [C(TK, 300, 1470, 1.0), C(EN, 700, 1240, 0.9, enter='fade'), C(EN, 880, 1300, 1.1, enter='fade', delay=10), C(EN, 540, 1190, 0.6, enter='fade')],
         CAM((1.0, 1.2)), FX(vignette=0.6, dust=0.5, tint='rgba(30,30,25,0.25)')))
S(45, SH(0, CR, [C(TK, 300, 1470, 1.3), C(EN, 850, 1300, 1.0, exit='fall', exitAt=12, exitDur=16)], CAM((1.0, 1.1)),
         FX(vignette=0.5, smoke=0.8, muzzle=[4], muzzleAt=[66, 60], flash=[4], impact=[10, 24], impactAt=[78, 66], shakePulses=[4, 14], pulseAmp=24)),
  sfx=[sfx('cannon', 4, 0.55)])
S(46, SH(0, BF, [C(TC, 220, 1540, 1.2, 'resolve', 'aim'), C(NS, 500, 1560, 1.1, 'resolve', 'aim'), C(EN, 800, 1330, 1.2)],
         CAM((1.0, 1.08)), FX(vignette=0.5, smoke=0.6, muzzle=[4, 14, 26, 38], muzzleAt=[36, 63], shakePulses=[4, 14, 26, 38], pulseAmp=8)),
  sfx=[sfx('gunfire', 4, 0.45), sfx('gunfire', 14, 0.45), sfx('gunfire', 26, 0.45)])
S(47, SH(0, BF, [C(NS, 250, 1540, 1.15, 'resolve', 'aim'),
                C(EN, 650, 1260, 0.7, exit='fall', exitAt=15), C(EN, 820, 1330, 0.9, exit='fall', exitAt=35), C(EN, 960, 1300, 0.8, exit='fall', exitAt=55)],
         CAM((1.0, 1.08)), FX(vignette=0.5, dust=0.4, muzzle=[4, 20, 36, 52, 68], muzzleAt=[46, 64], shakePulses=[4, 20, 36, 52, 68], pulseAmp=7)),
  sfx=[sfx('gunfire', 4, 0.4), sfx('gunfire', 36, 0.4), sfx('bullet-impact', 20, 0.3)])
S(48, SH(0, BF, [C(EN, 400, 1220, 0.7, enter='fade'), C(EN, 700, 1260, 0.9, enter='fade', delay=6), C(EN, 950, 1230, 0.7, enter='fade', delay=10),
                C(EN, 540, 1430, 1.4, enter='rise', delay=20)],
         CAM((1.0, 1.2)), FX(vignette=0.6, dust=0.8)))

# ---------------------------------------------------------------- 49-58: amunisi habis, awak gugur, komandan menyuruh keluar
S(49,
  SH(0, TI, [C(TC, 300, 1540, 1.2, 'grim'), C(NS, 760, 1570, 1.1, 'fear')], CAM((1.0, 1.15)),
     FX(vignette=0.55, smoke=0.4, tint=DARK, shakePulses=[30, 60], pulseAmp=8)),
  SH(70, TI, [C(NS, 540, 1590, 1.6, 'tired', 'aim')], CAM((1.2, 1.4)), FX(vignette=0.65, smoke=0.4, tint=DARK)),
  sfx=[sfx('reload', 20, 0.4), sfx('metal-impact', 40, 0.4)])
S(50, SH(0, TI, [C(VC, 160, 1520, 1.0, 'grim'), C(VC, 400, 1520, 1.0, 'grim'), C(VC, 640, 1520, 1.0, 'grim'), C(TC, 830, 1540, 1.0, 'grim', flip=True), C(NS, 990, 1570, 0.85, 'fear', flip=True)],
         CAM((1.0, 1.05)), FX(vignette=0.6, tint=DARK)))
S(51, SH(0, TI, [C(VC, 160, 1520, 1.0, 'grim', exit='fall', exitAt=8), C(VC, 400, 1520, 1.0, 'shock', exit='fall', exitAt=26),
                C(VC, 640, 1520, 1.0, 'grim', exit='fall', exitAt=44), C(TC, 830, 1540, 1.0, 'grim', flip=True), C(NS, 990, 1570, 0.85, 'fear', flip=True)],
         CAM((1.0, 1.08)), FX(vignette=0.6, smoke=0.7, tint=RED, flash=[8, 26, 44], shakePulses=[8, 26, 44], pulseAmp=16)),
  sfx=[sfx('metal-impact', 8, 0.5), sfx('metal-impact', 26, 0.5), sfx('metal-impact', 44, 0.5)])
S(52, SH(0, TI, [C(TC, 300, 1540, 1.25, 'tired'), C(NS, 760, 1570, 1.1, 'sad')], CAM((1.0, 1.1)), FX(vignette=0.7, smoke=0.5, tint=DARK)), lead=True)
S(53,
  SH(0, TI, [C(TC, 300, 1540, 1.3, 'tired', 'aim'), C(NS, 770, 1570, 1.15, 'tired', 'aim', flip=True)], CAM((1.0, 1.1)),
     FX(vignette=0.65, smoke=0.6, tint=DARK, shakePulses=[30, 70], pulseAmp=9)),
  SH(80, TI, [C(TC, 540, 1580, 1.6, 'tired')], CAM((1.1, 1.3)), FX(vignette=0.7, smoke=0.5, tint=DARK)))
S(54, SH(0, TI, [C(TC, 300, 1540, 1.3, 'grim'), C(NS, 780, 1570, 1.15, 'fear', flip=True)], CAM((1.0, 1.15)), FX(vignette=0.65, smoke=0.5, tint=DARK)))
S(55, SH(0, TI, [C(TC, 300, 1540, 1.35, 'grim'), C(NS, 780, 1570, 1.15, 'fear', flip=True)], CAM((1.1, 1.25)),
         FX(vignette=0.6, smoke=0.8, tint=RED, flash=[20, 50], shakePulses=[20, 50], pulseAmp=14)),
  sfx=[sfx('explosion', 20, 0.45), sfx('explosion', 50, 0.45)])
S(56,
  SH(0, TI, [C(TC, 300, 1540, 1.4, 'resolve'), C(NS, 780, 1570, 1.15, 'shock', flip=True)], CAM((1.0, 1.1), px=(0, 30)),
     FX(vignette=0.55, smoke=0.5, tint=DARK)),
  SH(70, TI, [C(TC, 700, 1560, 1.5, 'grim', flip=True), C(NS, 300, 1590, 1.1, 'sad')], CAM((1.0, 1.2)),
     FX(vignette=0.6, smoke=0.5, tint=DARK)))
S(57, SH(0, TI, [C(TC, 540, 1590, 1.7, 'tired')], CAM((1.2, 1.35)), FX(vignette=0.7, tint=DARK)))
S(58, SH(0, TI, [C(TC, 540, 1590, 1.75, 'resolve')], CAM((1.3, 1.45), o=(50, 35)), FX(vignette=0.7, smoke=0.4, tint=DARK)))

# ---------------------------------------------------------------- 59-71: bersembunyi, ditemukan, twist
S(59, SH(0, CR, [C(NS, 260, 1580, 1.1, 'fear', 'crouch'), C(TK, 700, 1470, 1.2)], CAM((1.0, 1.1)),
         FX(vignette=0.6, smoke=0.9, dust=0.7, tint=DUSK, flash=[20], shakePulses=[20, 45], pulseAmp=8)), lead=True,
  sfx=[sfx('footsteps', 10, 0.35)])
S(60, SH(0, UT, [C(NS, 540, 1620, 1.3, 'fear', 'crouch'), C(EN, 820, 1300, 0.5), C(EN, 300, 1320, 0.55)],
         CAM((1.0, 1.15), py=(0, -60)), FX(vignette=0.7, dust=0.8)))
S(61, SH(0, UT, [C(NS, 540, 1650, 1.3, 'fear', 'crouch', freeze=True),
                C(EN, 700, 1300, 0.7, exit='slide-left', exitAt=0, exitDur=90), C(EN, 950, 1330, 0.8, exit='slide-left', exitAt=20, exitDur=70)],
         CAM((1.0, 1.1)), FX(vignette=0.75, dust=0.9)),
  sfx=[sfx('footsteps', 0, 0.4)])
S(62, SH(0, UT, [C(NS, 300, 1700, 1.2, 'fear', 'crouch', freeze=True), C(GS, 800, 1260, 1.0, 'neutral', enter='slide-left')],
         CAM((1.0, 1.25), o=(70, 60)), FX(vignette=0.8)))
S(63, SH(0, UT, [C(NS, 540, 1660, 1.7, 'fear', 'crouch', freeze=True)], CAM((1.1, 1.3)), FX(vignette=0.85)))
S(64, SH(0, UT, [C(NS, 300, 1680, 1.2, 'fear', 'crouch', freeze=True), C(GS, 780, 1300, 1.15, 'neutral', flip=True)],
         CAM((1.0, 1.1)), FX(vignette=0.8)))
S(65, SH(0, UT, [C(NS, 300, 1690, 1.2, 'fear', 'crouch', freeze=True), C(GS, 800, 1300, 1.15, 'neutral', 'aim', flip=True)],
         CAM((1.1, 1.25), o=(60, 60)), FX(vignette=0.85)))
S(66, SH(0, UT, [C(NS, 300, 1690, 1.15, 'fear', 'crouch', freeze=True), C(GS, 800, 1300, 1.15, 'neutral'), C(EN, 1000, 1180, 0.6, enter='fade')],
         CAM((1.0, 1.05), px=(0, -30)), FX(vignette=0.8, dust=0.5)))
S(67, SH(0, UT, [C(NS, 300, 1690, 1.15, 'fear', 'crouch', freeze=True), C(GS, 800, 1300, 1.2, 'tired', flip=True)],
         CAM((1.05, 1.15)), FX(vignette=0.85)))
S(68, SH(0, UT, [C(NS, 250, 1700, 1.1, 'fear', 'crouch', freeze=True), C(GS, 700, 1280, 1.45, 'tired', flip=True)],
         CAM((1.1, 1.3), o=(60, 55)), FX(vignette=0.8)))
S(69, SH(0, UT, [C(NS, 300, 1690, 1.15, 'fear', 'crouch', freeze=True), C(GS, 780, 1300, 1.15, 'neutral', exit='slide-right', exitAt=4, exitDur=24)],
         CAM((1.15, 1.15)), FX(vignette=0.8, dust=0.4)),
  sfx=[sfx('footsteps', 0, 0.35)])
S(70, SH(0, UT, [C(NS, 540, 1680, 1.2, 'fear', 'crouch', freeze=True)], CAM((1.0, 1.25)),
         FX(vignette=0.7, tint='rgba(255,230,180,0.08)', flash=[0, 34], shakePulses=[0], pulseAmp=14)))
S(71,
  SH(0, UT, [C(NS, 270, 1560, 1.45, 'fear', 'stand', freeze=True), C(GS, 810, 1560, 1.45, 'fear', 'stand', flip=True, freeze=True)],
     CAM((1.0, 1.1)), FX(vignette=0.75)),
  SH(100, UT, [C(NS, 270, 1620, 1.45, 'tired', 'stand', freeze=True), C(GS, 810, 1620, 1.45, 'tired', 'stand', flip=True, freeze=True)],
     CAM((1.05, 1.15)), FX(vignette=0.75), 'fade'),
  SH(170, UT, [C(NS, 270, 1560, 1.45, 'sad', 'stand', freeze=True), C(GS, 810, 1560, 1.45, 'sad', 'stand', flip=True, freeze=True)],
     CAM((1.15, 1.05)), FX(vignette=0.8), 'fade'))

# ---------------------------------------------------------------- kata per kata
def word_timings(text, start, end):
    """SRT hanya punya timing per kalimat. Kata dibagi proporsional (panjang huruf)
    di dalam rentang start-end kalimat itu, tanpa keluar dari rentang tersebut."""
    words = text.split()
    weights = [len(re.sub(r'[^\w]', '', w, flags=re.UNICODE)) + 2.0 for w in words]
    total = sum(weights)
    out = []
    t = start
    for i, (w, wt) in enumerate(zip(words, weights)):
        e = end if i == len(words) - 1 else t + (end - start) * wt / total
        out.append({'word': w, 'start': round(t, 3), 'end': round(e, 3)})
        t = e
    return out


def build():
    scenes = []
    for i, seg in enumerate(SEGS):
        n = seg['index']
        spec = SPEC[n]
        start_f = seg['startFrame']
        dur_f = seg['durationInFrames']
        next_start = SEGS[i + 1]['startFrame'] if i + 1 < len(SEGS) else TOTAL
        visual = next_start - start_f
        lead = 8 if (spec['lead'] and start_f > 0) else 0
        shots = []
        for k, sh in enumerate(spec['shots']):
            nxt = spec['shots'][k + 1]['at'] if k + 1 < len(spec['shots']) else visual
            shots.append({
                'offset': sh['at'],
                'duration': nxt - sh['at'],
                'background': sh['bg'],
                'characters': sh['chars'],
                'camera': sh['cam'],
                'effects': sh['fx'],
                'transition': sh['tr'],
            })
        first = shots[0]
        scenes.append({
            'id': 'scene-%02d' % n,
            'segment': n,
            'startFrame': start_f,
            'durationInFrames': dur_f,
            'holdFrames': visual - dur_f,
            'visualDuration': visual,
            'lead': lead,
            'fadeOut': 24 if i == len(SEGS) - 1 else 0,
            'text': seg['text'],
            'background': first['background'],
            'characters': first['characters'],
            'effects': first['effects'],
            'voiceOver': '/audio/voiceover/segments/%02d.wav' % n,
            'subtitles': word_timings(seg['text'], seg['start'], seg['end']),
            'sfx': spec['sfx'],
            'shots': shots,
        })
    return scenes


def main():
    assert len(SEGS) == 71, 'timings.json harus berisi 71 segmen'
    assert set(SPEC) == set(range(1, 72)), 'SPEC harus mencakup 1..71'
    scenes = build()
    header = (
        '// FILE INI DIHASILKAN oleh tools/build_scenes.py dari public/audio/voiceover/timings.json.\n'
        '// startFrame, durationInFrames dan start/end subtitle berasal dari timings.json (tidak dikarang).\n'
        '// Pemetaan visual per segmen bisa diedit di tools/build_scenes.py lalu jalankan: npm run scenes\n\n'
    )
    body = 'export const scenes = ' + json.dumps(scenes, ensure_ascii=False, indent=1) + ';\n\n'
    body += 'export const TOTAL_FRAMES = %d;\nexport const FPS = %d;\n\nexport default scenes;\n' % (TOTAL, FPS)
    out = os.path.join(ROOT, 'src', 'scenes.js')
    with open(out, 'w', encoding='utf-8') as f:
        f.write(header + body)
    print('OK ->', out, len(scenes), 'scene')


if __name__ == '__main__':
    main()
